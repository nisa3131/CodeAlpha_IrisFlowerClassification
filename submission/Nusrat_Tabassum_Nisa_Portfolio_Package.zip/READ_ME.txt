PERSONAL DATA SCIENCE PROJECT PORTFOLIO
Prepared for Nusrat Tabassum Nisa

Contents:
- PDF: shareable one-page project portfolio.
- DOCX: editable Word version.
- TXT: plain-text portfolio.
- Email draft: request authentic certificate requirements and fee clarification.

This is a self-declared personal project record, not an employer-issued internship certificate. It does not claim company endorsement or certify internship completion.
The email is a draft only. No message has been sent and no certificate has been issued by this package.
GitHub URLs retain their existing repository names.
