"""Reproducible, group-aware used-vehicle price analysis for CodeAlpha Task 3."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
from typing import Any

# Keep both plotting and the font cache usable on a headless cloud machine.
os.environ.setdefault("MPLCONFIGDIR", "/tmp/codealpha-car-matplotlib")
os.environ.setdefault("XDG_CACHE_HOME", "/tmp/codealpha-car-cache")
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, GroupKFold, GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parent
SEED = 42
TARGET = "Selling_Price"
RAW_FEATURES = [
    "Car_Name", "Year", "Present_Price", "Driven_kms", "Fuel_Type",
    "Selling_type", "Transmission", "Owner",
]
NUMERIC = ["Vehicle_Age", "Present_Price", "Driven_kms", "Owner"]
CATEGORICAL = ["Car_Name", "Fuel_Type", "Selling_type", "Transmission"]


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def load_data(path: Path) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Validate the schema and deduplicate records before any split."""
    raw = pd.read_csv(path)
    expected = RAW_FEATURES + [TARGET]
    if set(raw.columns) != set(expected):
        raise ValueError(f"Expected columns {expected}; got {list(raw.columns)}")
    numeric = ["Year", "Present_Price", "Driven_kms", "Owner", TARGET]
    for column in numeric:
        raw[column] = pd.to_numeric(raw[column], errors="raise")
        if np.isinf(raw[column].dropna()).any():
            raise ValueError(f"Infinite values in {column}")
    if raw[TARGET].isna().any() or (raw[TARGET] <= 0).any():
        raise ValueError("Selling_Price must be present and positive")
    if raw["Year"].isna().all():
        raise ValueError("At least one vehicle year is required")
    for column in ["Present_Price", "Driven_kms", "Owner"]:
        if (raw[column].dropna() < 0).any():
            raise ValueError(f"Negative values in {column}")
    duplicates = raw.duplicated(keep="first")
    deduped = raw.loc[~duplicates].copy()
    # Preserve the original CSV line numbers for a transparent audit trail.
    deduped.insert(0, "source_csv_row", deduped.index + 2)
    name_before = deduped["Car_Name"].copy()
    for column in CATEGORICAL:
        deduped[column] = (
            deduped[column].astype("string").str.strip().str.lower()
            .str.replace(r"\s+", " ", regex=True).replace("", pd.NA)
        )
    # Normalize representations before grouping, without inventing brand mappings.
    normalized_duplicates = deduped.duplicated(subset=expected, keep="first")
    deduped = deduped.loc[~normalized_duplicates].copy().reset_index(drop=True)
    audit = {
        "source_file": path.name,
        "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "raw_rows": len(raw),
        "columns": list(raw.columns),
        "exact_duplicates_removed": int(duplicates.sum()),
        "exact_duplicate_csv_rows_removed": (raw.index[duplicates] + 2).tolist(),
        "additional_duplicates_after_text_normalization": int(normalized_duplicates.sum()),
        "rows_after_deduplication": len(deduped),
        "missing_values_raw": {key: int(value) for key, value in raw.isna().sum().items()},
        "normalized_vehicle_name_count": int(deduped["Car_Name"].nunique()),
        "vehicle_name_rows_normalized": int((name_before.fillna("").astype(str) != (
            name_before.astype("string").str.strip().str.lower().str.replace(r"\s+", " ", regex=True)
            .fillna("").astype(str))).sum()),
        "dataset_year_range": [int(raw["Year"].min()), int(raw["Year"].max())],
        "reference_year": int(raw["Year"].max()),
        "reference_year_meaning": "Maximum year in the supplied dataset, not its verified collection date or the current year.",
        "mileage_range_km": [int(raw["Driven_kms"].min()), int(raw["Driven_kms"].max())],
        "target_range_dataset_price_units": [float(raw[TARGET].min()), float(raw[TARGET].max())],
        "currency": "Not verified; all prices and errors use the original dataset price units.",
        "scope": "The data includes cars, motorcycles and scooters.",
    }
    return deduped, audit


def make_features(df: pd.DataFrame, reference_year: int) -> pd.DataFrame:
    """Use a fixed historical year reference, never today's year."""
    features = df[RAW_FEATURES].copy()
    features["Vehicle_Age"] = reference_year - features.pop("Year")
    for column in CATEGORICAL:
        # SimpleImputer uses np.nan for missing categorical values.
        features[column] = features[column].astype(object).where(features[column].notna(), np.nan)
    return features[NUMERIC + CATEGORICAL]


def preprocessing() -> ColumnTransformer:
    numeric = Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler()),
    ])
    categorical = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("encode", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    return ColumnTransformer([("numeric", numeric, NUMERIC), ("categorical", categorical, CATEGORICAL)])


def candidates() -> list[tuple[str, Any, dict[str, list[Any]]]]:
    return [
        ("dummy_median", DummyRegressor(strategy="median"), {}),
        ("ridge", Ridge(), {"model__alpha": [0.1, 1.0, 10.0, 100.0]}),
        (
            "random_forest", RandomForestRegressor(n_estimators=300, random_state=SEED, n_jobs=1),
            {"model__max_depth": [None, 6], "model__min_samples_leaf": [1, 3]},
        ),
        (
            "gradient_boosting", GradientBoostingRegressor(random_state=SEED, learning_rate=0.05),
            {"model__n_estimators": [150, 300], "model__max_depth": [2, 3]},
        ),
    ]


def scores(y: pd.Series, prediction: np.ndarray) -> dict[str, float]:
    return {
        "mae": float(mean_absolute_error(y, prediction)),
        "rmse": float(np.sqrt(mean_squared_error(y, prediction))),
        "r2": float(r2_score(y, prediction)),
    }


def save_plot(path: Path) -> None:
    plt.tight_layout()
    plt.savefig(path, dpi=160, bbox_inches="tight")
    plt.close()


def make_plots(
    df: pd.DataFrame,
    holdout: pd.DataFrame,
    cv_summary: list[dict[str, Any]],
    importance: pd.DataFrame,
    charts: Path,
) -> None:
    charts.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].hist(df[TARGET], bins=22, color="#2563a5", edgecolor="white")
    axes[0].set(xlabel="Selling price (dataset price units)", ylabel="Unique listings", title="Historical used-vehicle prices")
    axes[1].scatter(df["Present_Price"], df[TARGET], alpha=0.65, color="#0f766e", s=24)
    axes[1].set(xlabel="Present price (dataset price units)", ylabel="Selling price (dataset price units)", title="A strong price-related input")
    save_plot(charts / "data_overview.png")

    plt.figure(figsize=(8, 4))
    ordered = sorted(cv_summary, key=lambda row: row["cv_mae_mean"])
    plt.barh([row["model"] for row in ordered], [row["cv_mae_mean"] for row in ordered],
             xerr=[row["cv_mae_std"] for row in ordered], color="#2563a5", capsize=3)
    plt.gca().invert_yaxis()
    plt.xlabel("Grouped cross-validation MAE (dataset price units; lower is better)")
    plt.title("Training-only model selection; bars show fold standard deviation")
    save_plot(charts / "cv_comparison.png")

    actual, predicted = holdout["actual_selling_price"], holdout["predicted_selling_price"]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].scatter(actual, predicted, s=28, alpha=0.75, color="#2563a5")
    low = min(float(actual.min()), float(predicted.min()))
    high = max(float(actual.max()), float(predicted.max()))
    axes[0].plot([low, high], [low, high], linestyle="--", color="gray")
    axes[0].set(xlabel="Actual price (dataset price units)", ylabel="Predicted price (dataset price units)", title="Held-out vehicle models")
    axes[1].scatter(predicted, holdout["residual_actual_minus_predicted"], s=28, alpha=0.75, color="#0f766e")
    axes[1].axhline(0, linestyle="--", color="gray")
    axes[1].set(xlabel="Predicted price (dataset price units)", ylabel="Actual − predicted (dataset price units)", title="Residuals on the untouched test split")
    save_plot(charts / "heldout_predictions_and_residuals.png")

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ordered_importance = importance.sort_values("mae_increase_mean")
    ax.barh(ordered_importance["feature"], ordered_importance["mae_increase_mean"],
            xerr=ordered_importance["mae_increase_std"], color="#0f766e", capsize=3)
    ax.axvline(0, color="gray", linewidth=1)
    ax.set(xlabel="Increase in held-out MAE after permutation (dataset price units)",
           title="Descriptive importance after model selection (20 repeats)")
    save_plot(charts / "permutation_importance.png")


def build_summary(metrics: dict[str, Any]) -> str:
    evaluation = metrics["test_metrics"]
    rows = "\n".join(
        f"| {name} | {item['mae']:.4f} | {item['rmse']:.4f} | {item['r2']:.4f} |"
        for name, item in evaluation.items()
    )
    cv_rows = "\n".join(
        f"| {item['model']} | {item['cv_mae_mean']:.4f} | {item['cv_mae_std']:.4f} |"
        for item in metrics["cross_validation"]
    )
    return f"""# Used-Vehicle Price Prediction — Design Report

## Objective
Complete CodeAlpha Task 3 by predicting `Selling_Price` from the supplied historical vehicle attributes. The file also contains motorcycles and scooters, so this report describes used vehicles. This is an educational regression analysis, not a current-market valuation service.

## Data and assumptions
The user-supplied `data/car data.csv` contains {metrics['data']['raw_rows']} rows. Removing {metrics['data']['exact_duplicates_removed']} exact duplicate records leaves {metrics['data']['rows_after_deduplication']} unique records. No values are missing in the supplied file. Text case and whitespace are normalized before grouping; no brands, horsepower values, or goodwill ratings are invented. Currency metadata is absent: prices, MAE, and RMSE are all in **dataset price units**, without a currency conversion or an asserted lakh denomination. The task document attributes the dataset to [Kaggle: Car Price Prediction (Used Cars)](https://www.kaggle.com/datasets/vijayaadithyanvg/car-price-predictionused-cars); the actual input is the user-uploaded CSV and the data license has not been independently verified.

The years span 2003–2018. `Vehicle_Age = {metrics['data']['reference_year']} − Year` uses the dataset's maximum year as a fixed historical reference. That is not a claim about the collection date or the vehicles' ages today. The mileage outlier of 500,000 km and rare ownership/fuel categories are retained rather than silently removed.

## Method and leakage controls
After deduplication, a seeded `GroupShuffleSplit` holds out 20% of normalized vehicle-name groups: **{metrics['split']['train_rows']} training rows / {metrics['split']['test_rows']} test rows**, comprising {metrics['split']['train_groups']} / {metrics['split']['test_groups']} vehicle-name groups. No normalized name appears on both sides. The fraction applies to groups, so the exact row fraction differs from 20%. This deliberately measures generalization to **unseen vehicle models**, not random listings of models already represented in training.

Median imputation and scaling for numeric fields, and most-frequent imputation plus one-hot encoding for categorical fields, are fitted inside each training fold through a `ColumnTransformer` pipeline. Unknown categories are ignored safely. All five `GroupKFold` validation folds keep names disjoint. Candidate hyperparameters are chosen solely by mean training-fold MAE. The dummy median, regularized Ridge, random forest, and gradient boosting candidates use the same folds. The selected model and dummy baseline are evaluated once on the untouched test set; test errors and permutation importance do not select or tune the model.

## Training-only model comparison

| Model | Mean CV MAE | Fold standard deviation |
| --- | ---: | ---: |
{cv_rows}

Selected model: **{metrics['selected_model']}**. Best parameters: `{json.dumps(metrics['selected_parameters'], sort_keys=True)}`. Fold standard deviations describe variation among five folds, not a confidence interval.

## Held-out results

| Model | MAE ↓ | RMSE ↓ | R² ↑ |
| --- | ---: | ---: | ---: |
{rows}

The selected model reduces test MAE by {metrics['baseline_relative_mae_improvement_percent']:.1f}% versus the median baseline. The held-out error is substantially larger than the selected model's mean CV error, illustrating uncertainty when generalizing across a small number of vehicle models. No model is retuned after that result. R² is a split-specific comparison against a constant test-set mean; it does not establish real-market accuracy. `heldout_predictions.csv` records each prediction, original CSV row, and residual. The saved model is the training-only fitted model, preserving the test boundary.

## Interpretation and limitations
The residual chart shows individual mistakes and the permutation plot measures how much shuffling each supplied input worsens held-out MAE after selection. These are associations, not causal effects. Correlated inputs can share or mask importance. `Car_Name` is always unseen at test time under this protocol, so its encoded categories are all unknown and its test permutation importance is zero by construction.

This small, historical convenience sample has no verified location, collection date, currency, accident history, condition, or service history. It mixes vehicle types, contains high mileage outliers and rare CNG/ownership categories, and is not an independent external validation sample. Name normalization cannot establish listing identity beyond exact duplicates. Repeated similar records within a name stay on one side of every split, but unidentified duplicates under different names cannot be ruled out. A single seeded holdout gives a reproducible estimate, not a stable population confidence interval. `Present_Price` is useful only when available at prediction time; its meaning/timestamp must be verified for deployment. Negative model predictions are not clipped or hidden. Production use needs representative, dated data and a deployment-specific validation plan.

## Reproducibility and artifacts
Run `python analysis.py` from any working directory. The CLI resolves defaults relative to `analysis.py`, uses seed 42 and a headless plotting backend, records package versions and the source SHA-256, and never changes the raw CSV. `analysis.ipynb` runs the same pipeline and displays the report and plots. `metrics.json`, `data_audit.json`, `cv_results.csv`, `split_assignments.csv`, `heldout_predictions.csv`, `permutation_importance.csv`, the four chart PNGs, and `model.joblib` are generated under `outputs/`. Only load a joblib/pickle artifact from a trusted source.
"""


def run(data_path: Path, output_dir: Path) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    df, audit = load_data(data_path)
    features = make_features(df, audit["reference_year"])
    target = df[TARGET]
    groups = df["Car_Name"].fillna("__missing_vehicle_name__")
    train_idx, test_idx = next(GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=SEED).split(features, target, groups))
    x_train, x_test = features.iloc[train_idx], features.iloc[test_idx]
    y_train, y_test = target.iloc[train_idx], target.iloc[test_idx]
    train_groups, test_groups = groups.iloc[train_idx], groups.iloc[test_idx]
    if not set(train_groups).isdisjoint(set(test_groups)):
        raise RuntimeError("Vehicle-name leakage across the test boundary")
    if train_groups.nunique() < 5:
        raise ValueError("Five distinct training vehicle models are required for five-fold group CV")
    folds = list(GroupKFold(n_splits=5).split(x_train, y_train, train_groups))
    for fit_idx, validation_idx in folds:
        if not set(train_groups.iloc[fit_idx]).isdisjoint(set(train_groups.iloc[validation_idx])):
            raise RuntimeError("Vehicle-name leakage within cross-validation")

    summaries, searches, cv_records = [], {}, []
    for name, estimator, grid in candidates():
        pipeline = Pipeline([("preprocess", preprocessing()), ("model", estimator)])
        search = GridSearchCV(
            pipeline, grid, scoring="neg_mean_absolute_error", cv=folds,
            n_jobs=1, refit=True, error_score="raise", return_train_score=False,
        )
        search.fit(x_train, y_train)
        searches[name] = search
        best_idx = search.best_index_
        summaries.append({
            "model": name,
            "cv_mae_mean": float(-search.best_score_),
            "cv_mae_std": float(search.cv_results_["std_test_score"][best_idx]),
            "best_parameters": search.best_params_,
            "fold_mae": [float(-search.cv_results_[f"split{fold}_test_score"][best_idx]) for fold in range(5)],
        })
        for candidate_idx, params in enumerate(search.cv_results_["params"]):
            cv_records.append({
                "model": name, "parameters": json.dumps(params, sort_keys=True),
                "cv_mae_mean": float(-search.cv_results_["mean_test_score"][candidate_idx]),
                "cv_mae_std": float(search.cv_results_["std_test_score"][candidate_idx]),
                **{f"fold_{fold+1}_mae": float(-search.cv_results_[f"split{fold}_test_score"][candidate_idx]) for fold in range(5)},
            })
        print(f"{name}: best training CV MAE = {-search.best_score_:.4f}", flush=True)

    selected_name = min(summaries, key=lambda item: item["cv_mae_mean"])["model"]
    selected = searches[selected_name].best_estimator_
    # Freeze selection before inspecting test predictions.
    predicted = selected.predict(x_test)
    baseline = searches["dummy_median"].best_estimator_.predict(x_test)
    test_metrics = {"dummy_median": scores(y_test, baseline), selected_name: scores(y_test, predicted)}
    holdout = df.iloc[test_idx].copy()
    holdout["actual_selling_price"] = y_test.to_numpy()
    holdout["predicted_selling_price"] = predicted
    holdout["baseline_predicted_selling_price"] = baseline
    holdout["residual_actual_minus_predicted"] = y_test.to_numpy() - predicted
    holdout["absolute_error"] = np.abs(holdout["residual_actual_minus_predicted"])
    holdout.to_csv(output_dir / "heldout_predictions.csv", index=False)

    permutation = permutation_importance(selected, x_test, y_test, scoring="neg_mean_absolute_error", n_repeats=20, random_state=SEED, n_jobs=1)
    importance = pd.DataFrame({
        "feature": x_test.columns, "mae_increase_mean": permutation.importances_mean,
        "mae_increase_std": permutation.importances_std,
    }).sort_values("mae_increase_mean", ascending=False)
    importance.to_csv(output_dir / "permutation_importance.csv", index=False)
    assignments = df[["source_csv_row", "Car_Name"]].copy()
    assignments["split"] = "train"
    assignments.loc[test_idx, "split"] = "test"
    assignments["cv_validation_fold"] = pd.Series(pd.NA, index=assignments.index, dtype="Int64")
    for fold_number, (_, validation_idx) in enumerate(folds, start=1):
        assignments.loc[train_idx[validation_idx], "cv_validation_fold"] = fold_number
    assignments.to_csv(output_dir / "split_assignments.csv", index=False)
    pd.DataFrame(cv_records).to_csv(output_dir / "cv_results.csv", index=False)

    baseline_mae = test_metrics["dummy_median"]["mae"]
    metrics = {
        "task": "CodeAlpha Task 3 — Car Price Prediction", "seed": SEED,
        "data": audit,
        "split": {
            "strategy": "GroupShuffleSplit by normalized Car_Name; test_size=0.2 of groups",
            "train_rows": len(train_idx), "test_rows": len(test_idx),
            "train_groups": int(train_groups.nunique()), "test_groups": int(test_groups.nunique()),
            "group_overlap": 0, "cv_folds": 5, "cv_strategy": "GroupKFold by normalized Car_Name",
        },
        "selection_metric": "Minimum mean training-only group CV MAE",
        "cross_validation": summaries,
        "selected_model": selected_name, "selected_parameters": searches[selected_name].best_params_,
        "test_metrics": test_metrics,
        "baseline_relative_mae_improvement_percent": float(100 * (1 - test_metrics[selected_name]["mae"] / baseline_mae)),
        "negative_test_predictions": int((predicted < 0).sum()),
        "numeric_features": NUMERIC, "categorical_features": CATEGORICAL,
        "package_versions": {package: importlib.metadata.version(package) for package in ["numpy", "pandas", "scikit-learn", "matplotlib", "joblib"]},
        "model_artifact_scope": "Training-only fit; not refitted on the held-out test data.",
    }
    make_plots(df, holdout, summaries, importance, output_dir / "charts")
    joblib.dump({"pipeline": selected, "reference_year": audit["reference_year"],
                 "features": NUMERIC + CATEGORICAL, "target": TARGET,
                 "units": "unverified dataset price units", "selected_model": selected_name}, output_dir / "model.joblib", compress=3)
    write_json(output_dir / "data_audit.json", audit)
    write_json(output_dir / "metrics.json", metrics)
    (output_dir / "summary.md").write_text(build_summary(metrics), encoding="utf-8")
    print(f"Selected {selected_name}; held-out MAE = {test_metrics[selected_name]['mae']:.4f}, RMSE = {test_metrics[selected_name]['rmse']:.4f}, R² = {test_metrics[selected_name]['r2']:.4f}")
    print(f"Artifacts saved to {output_dir}")
    return metrics


def main(argv: list[str] | None = None) -> dict[str, Any]:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data" / "car data.csv")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs")
    args = parser.parse_args(argv)
    return run(args.data.expanduser().resolve(), args.output_dir.expanduser().resolve())


if __name__ == "__main__":
    main()
