"""Checks of the saved experiment's leakage boundary and reported results."""
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import analysis


class SavedExperimentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.df, cls.audit = analysis.load_data(ROOT / "data" / "car data.csv")
        cls.metrics = json.loads((ROOT / "outputs" / "metrics.json").read_text())
        cls.assignments = pd.read_csv(ROOT / "outputs" / "split_assignments.csv")
        cls.predictions = pd.read_csv(ROOT / "outputs" / "heldout_predictions.csv")

    def test_duplicates_and_historical_reference(self):
        original = pd.read_csv(ROOT / "data" / "car data.csv")
        self.assertEqual(self.audit["exact_duplicates_removed"], int(original.duplicated().sum()))
        self.assertEqual(self.audit["reference_year"], original["Year"].max())
        features = analysis.make_features(self.df, self.audit["reference_year"])
        np.testing.assert_array_equal(features["Vehicle_Age"], original["Year"].max() - self.df["Year"])
        self.assertNotIn(analysis.TARGET, features.columns)
        self.assertNotIn("Year", features.columns)

    def test_no_vehicle_group_leakage(self):
        assignments = self.assignments
        train = assignments[assignments["split"] == "train"]
        test = assignments[assignments["split"] == "test"]
        self.assertTrue(set(train["Car_Name"]).isdisjoint(test["Car_Name"]))
        self.assertEqual(train.groupby("Car_Name")["cv_validation_fold"].nunique().max(), 1)
        self.assertEqual(set(train["cv_validation_fold"]), {1, 2, 3, 4, 5})
        self.assertTrue(test["cv_validation_fold"].isna().all())
        self.assertEqual(set(assignments["source_csv_row"]), set(self.df["source_csv_row"]))
        self.assertEqual(len(assignments), len(self.df))

    def test_selected_by_cv_and_test_metrics_recompute(self):
        metrics = self.metrics
        self.assertEqual(metrics["selected_model"], min(metrics["cross_validation"], key=lambda row: row["cv_mae_mean"])["model"])
        actual = self.predictions["actual_selling_price"]
        predicted = self.predictions["predicted_selling_price"]
        saved = metrics["test_metrics"][metrics["selected_model"]]
        self.assertAlmostEqual(saved["mae"], mean_absolute_error(actual, predicted))
        self.assertAlmostEqual(saved["rmse"], np.sqrt(mean_squared_error(actual, predicted)))
        self.assertAlmostEqual(saved["r2"], r2_score(actual, predicted))
        train_rows = self.assignments.loc[self.assignments["split"] == "train", "source_csv_row"]
        train_median = self.df.loc[self.df["source_csv_row"].isin(train_rows), analysis.TARGET].median()
        np.testing.assert_allclose(self.predictions["baseline_predicted_selling_price"], train_median)
        self.assertTrue(np.isfinite(predicted).all())

    def test_saved_pipeline_handles_unknown_categories_and_missing_inputs(self):
        bundle = joblib.load(ROOT / "outputs" / "model.joblib")
        inputs = analysis.make_features(self.df.iloc[:2], bundle["reference_year"])
        inputs.loc[inputs.index[0], analysis.NUMERIC] = np.nan
        inputs.loc[inputs.index[0], analysis.CATEGORICAL] = "unseen-category"
        inputs.loc[inputs.index[1], analysis.CATEGORICAL] = np.nan
        predictions = bundle["pipeline"].predict(inputs)
        self.assertEqual(predictions.shape, (2,))
        self.assertTrue(np.isfinite(predictions).all())


if __name__ == "__main__":
    unittest.main()
