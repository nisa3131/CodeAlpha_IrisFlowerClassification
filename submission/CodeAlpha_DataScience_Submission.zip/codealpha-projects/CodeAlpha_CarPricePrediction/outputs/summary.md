# Used-Vehicle Price Prediction — Design Report

## Objective
Complete CodeAlpha Task 3 by predicting `Selling_Price` from the supplied historical vehicle attributes. The file also contains motorcycles and scooters, so this report describes used vehicles. This is an educational regression analysis, not a current-market valuation service.

## Data and assumptions
The user-supplied `data/car data.csv` contains 301 rows. Removing 2 exact duplicate records leaves 299 unique records. No values are missing in the supplied file. Text case and whitespace are normalized before grouping; no brands, horsepower values, or goodwill ratings are invented. Currency metadata is absent: prices, MAE, and RMSE are all in **dataset price units**, without a currency conversion or an asserted lakh denomination. The task document attributes the dataset to [Kaggle: Car Price Prediction (Used Cars)](https://www.kaggle.com/datasets/vijayaadithyanvg/car-price-predictionused-cars); the actual input is the user-uploaded CSV and the data license has not been independently verified.

The years span 2003–2018. `Vehicle_Age = 2018 − Year` uses the dataset's maximum year as a fixed historical reference. That is not a claim about the collection date or the vehicles' ages today. The mileage outlier of 500,000 km and rare ownership/fuel categories are retained rather than silently removed.

## Method and leakage controls
After deduplication, a seeded `GroupShuffleSplit` holds out 20% of normalized vehicle-name groups: **229 training rows / 70 test rows**, comprising 77 / 20 vehicle-name groups. No normalized name appears on both sides. The fraction applies to groups, so the exact row fraction differs from 20%. This deliberately measures generalization to **unseen vehicle models**, not random listings of models already represented in training.

Median imputation and scaling for numeric fields, and most-frequent imputation plus one-hot encoding for categorical fields, are fitted inside each training fold through a `ColumnTransformer` pipeline. Unknown categories are ignored safely. All five `GroupKFold` validation folds keep names disjoint. Candidate hyperparameters are chosen solely by mean training-fold MAE. The dummy median, regularized Ridge, random forest, and gradient boosting candidates use the same folds. The selected model and dummy baseline are evaluated once on the untouched test set; test errors and permutation importance do not select or tune the model.

## Training-only model comparison

| Model | Mean CV MAE | Fold standard deviation |
| --- | ---: | ---: |
| dummy_median | 3.2631 | 0.9471 |
| ridge | 1.0617 | 0.2976 |
| random_forest | 0.9258 | 0.4306 |
| gradient_boosting | 0.9504 | 0.5795 |

Selected model: **random_forest**. Best parameters: `{"model__max_depth": null, "model__min_samples_leaf": 3}`. Fold standard deviations describe variation among five folds, not a confidence interval.

## Held-out results

| Model | MAE ↓ | RMSE ↓ | R² ↑ |
| --- | ---: | ---: | ---: |
| dummy_median | 3.4954 | 5.4453 | -0.0975 |
| random_forest | 2.0562 | 3.3528 | 0.5839 |

The selected model reduces test MAE by 41.2% versus the median baseline. The held-out error is substantially larger than the selected model's mean CV error, illustrating uncertainty when generalizing across a small number of vehicle models. No model is retuned after that result. R² is a split-specific comparison against a constant test-set mean; it does not establish real-market accuracy. `heldout_predictions.csv` records each prediction, original CSV row, and residual. The saved model is the training-only fitted model, preserving the test boundary.

## Interpretation and limitations
The residual chart shows individual mistakes and the permutation plot measures how much shuffling each supplied input worsens held-out MAE after selection. These are associations, not causal effects. Correlated inputs can share or mask importance. `Car_Name` is always unseen at test time under this protocol, so its encoded categories are all unknown and its test permutation importance is zero by construction.

This small, historical convenience sample has no verified location, collection date, currency, accident history, condition, or service history. It mixes vehicle types, contains high mileage outliers and rare CNG/ownership categories, and is not an independent external validation sample. Name normalization cannot establish listing identity beyond exact duplicates. Repeated similar records within a name stay on one side of every split, but unidentified duplicates under different names cannot be ruled out. A single seeded holdout gives a reproducible estimate, not a stable population confidence interval. `Present_Price` is useful only when available at prediction time; its meaning/timestamp must be verified for deployment. Negative model predictions are not clipped or hidden. Production use needs representative, dated data and a deployment-specific validation plan.

## Reproducibility and artifacts
Run `python analysis.py` from any working directory. The CLI resolves defaults relative to `analysis.py`, uses seed 42 and a headless plotting backend, records package versions and the source SHA-256, and never changes the raw CSV. `analysis.ipynb` runs the same pipeline and displays the report and plots. `metrics.json`, `data_audit.json`, `cv_results.csv`, `split_assignments.csv`, `heldout_predictions.csv`, `permutation_importance.csv`, the four chart PNGs, and `model.joblib` are generated under `outputs/`. Only load a joblib/pickle artifact from a trusted source.
