# CodeAlpha — Car Price Prediction

Predict used-vehicle resale prices using age, current price, distance driven, and vehicle attributes. This Python project includes preprocessing, regression-model comparison, held-out evaluation, an executed notebook, and reports; the supplied data contains both cars and two-wheelers.

Read the full [design report](outputs/summary.md), explore the [executed notebook](analysis.ipynb), or run the [Python pipeline](analysis.py). The report covers objectives, data, methods, results, limitations, and reproducibility.

## Results

After removing two exact duplicates, 299 unique records remain. A seed-42 group split reserves 70 rows from 20 vehicle-name groups for testing; 229 rows from 77 other groups form the training set. Five-fold group cross-validation selects hyperparameters and a model using only training data. Names never overlap between training and validation/test groups. This tests generalization to **unseen vehicle models**, rather than randomly held-out listings of previously observed models.

| Model | Test MAE ↓ | Test RMSE ↓ | Test R² ↑ |
| --- | ---: | ---: | ---: |
| Median dummy baseline | 3.4954 | 5.4453 | −0.0975 |
| Random forest, selected by training-only CV | 2.0562 | 3.3528 | 0.5839 |

The selected model reduces test MAE by **41.2%** relative to the median baseline. Its mean CV MAE is 0.9258; the higher held-out error shows substantial uncertainty across different vehicle models. These are measured results, not a promise of current-market accuracy. No test-based tuning or clipping is applied. MAE, RMSE, and all prices use **dataset price units**; currency and denomination were not verified.

![Held-out predictions and residuals](outputs/charts/heldout_predictions_and_residuals.png)

## Reproduce

Verified with Python **3.12.14**. Runtime dependencies are pinned to the installed versions.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python analysis.py
python -m unittest discover -s tests -v
```

The CLI resolves its defaults relative to `analysis.py`, so it also works from another directory:

```bash
python /path/to/CodeAlpha_CarPricePrediction/analysis.py
```

Override paths when needed:

```bash
python analysis.py --data "data/car data.csv" --output-dir outputs
```

Open `analysis.ipynb` in a Jupyter-compatible editor using the same Python environment, then run all cells. It imports and runs the same guarded CLI implementation, displays the report and charts, and shows held-out examples. For programmatic notebook execution, the optional verified tooling is in `requirements-notebook.txt`:

```bash
python -m pip install -r requirements-notebook.txt
```

No credentials, remote data download, database, or GPU is needed. The pipeline uses a noninteractive plotting backend and one worker to remain suitable for small cloud environments. Running it regenerates `outputs/` while preserving the raw CSV. `model.joblib` is regenerated locally and excluded from Git; it is a training-only model bundle containing the preprocessing pipeline, historical reference year, feature names, and unit metadata. Load joblib artifacts only from a trusted source.

## Data and features

Actual input: the user-uploaded CSV, preserved unchanged under `data/`. The CodeAlpha task document links to [Kaggle: Car Price Prediction (Used Cars)](https://www.kaggle.com/datasets/vijayaadithyanvg/car-price-predictionused-cars). That is attribution from the document; collection date, currency, and dataset reuse rights have not been independently verified. No dataset license is asserted by this repository.

| Supplied field | Treatment |
| --- | --- |
| `Selling_Price` | Regression target; never an input |
| `Car_Name` | Normalize case/whitespace; categorical input and leakage-prevention group |
| `Year` | Replace with `Vehicle_Age = 2018 − Year`; 2018 is the dataset's maximum year, not today's year or a verified collection date |
| `Present_Price` | Numeric input; must be available with a compatible meaning at prediction time |
| `Driven_kms` | Numeric input; preserve the observed 500,000 km extreme |
| `Fuel_Type`, `Selling_type`, `Transmission` | Categorical inputs with safe unknown-category handling |
| `Owner` | Numeric prior-ownership input; preserve rare values |

The file has no missing values. Numeric median imputation, standard scaling, categorical most-frequent imputation, and one-hot encoding are nevertheless fitted inside each training fold to support the documented schema. No horsepower, brand, goodwill, current age, or current price is invented. Models compared are a median dummy, regularized Ridge, random forest, and gradient boosting. Candidate selection minimizes five-fold training-only grouped MAE.

## Artifacts

| File | Purpose |
| --- | --- |
| [outputs/summary.md](outputs/summary.md) | Complete design report with measured results and limitations |
| [outputs/metrics.json](outputs/metrics.json) | Seed, source SHA-256, versions, splits, CV selection, and test metrics |
| [outputs/data_audit.json](outputs/data_audit.json) | Schema, duplicate removal, missingness, and data ranges |
| [outputs/cv_results.csv](outputs/cv_results.csv) | Every candidate's training-only validation results |
| [outputs/split_assignments.csv](outputs/split_assignments.csv) | Original CSV row, group, train/test boundary, and validation fold |
| [outputs/heldout_predictions.csv](outputs/heldout_predictions.csv) | Every held-out actual, prediction, baseline, and residual |
| [outputs/permutation_importance.csv](outputs/permutation_importance.csv) | Descriptive held-out importance after model selection |
| [outputs/charts/](outputs/charts/) | Data overview, CV comparison, predictions/residuals, and importance |
| `outputs/model.joblib` (generated locally) | Selected fitted training-only pipeline and metadata |

The original CSV row numbers include the header, so the first data row is row 2. Permutation importance is descriptive, does not establish causation, and can be affected by correlated inputs. Since every test vehicle name is unseen, its one-hot columns are unknown at test time and its test importance is zero by construction.

## Limitations and validation

This is a small historical convenience sample with mixed vehicle types, rare categories, high mileage outliers, and unknown geography, condition, accident history, collection date, and currency. Name grouping reduces leakage from similar listings but cannot verify that different names never describe the same listing. A single held-out group split is not external validation or a population confidence interval. `Present_Price` requires a verified operational definition before deployment. This repository supports educational analysis, not production valuation.

Four meaningful validation checks confirm duplicate handling and the historical reference year; disjoint vehicle groups in the test split and all five CV folds; independent recomputation of reported test metrics and the training-median baseline; and finite saved-pipeline predictions with unknown categories and missing numeric inputs. Notebook execution provides an additional end-to-end reproducibility check.

## Report exports

- [Formatted design report](REPORT.md)
- [PDF report](report/report.pdf)
- [Editable DOCX report](report/report.docx)

The committed notebook contains outputs from a successful full execution. The included GitHub Actions workflow reproduces the analysis on Python 3.12. View the Actions tab for the current GitHub run status.

## Submission downloads

- [Complete four-project submission package](https://raw.githubusercontent.com/nisa3131/CodeAlpha_IrisFlowerClassification/main/submission/CodeAlpha_DataScience_Submission.zip)
- [Combined PDF report](https://raw.githubusercontent.com/nisa3131/CodeAlpha_IrisFlowerClassification/main/submission/CodeAlpha_DataScience_Design_Report.pdf) · [Editable Word report](https://raw.githubusercontent.com/nisa3131/CodeAlpha_IrisFlowerClassification/main/submission/CodeAlpha_DataScience_Design_Report.docx)
- [Submission checklist](https://raw.githubusercontent.com/nisa3131/CodeAlpha_IrisFlowerClassification/main/submission/SUBMISSION_CHECKLIST.pdf) · [Video explanation scripts](https://raw.githubusercontent.com/nisa3131/CodeAlpha_IrisFlowerClassification/main/submission/VIDEO_EXPLANATION_SCRIPTS.md)
- [Download this project as a ZIP](https://github.com/nisa3131/CodeAlpha_CarPricePrediction/archive/refs/heads/main.zip)

The complete package includes the four projects, executed notebooks, datasets, results, charts, individual reports, the combined report, and submission guidance. The shared downloads are hosted in the Iris repository's `submission/` folder. Record/post the required explanation videos and complete the official submission form separately.
