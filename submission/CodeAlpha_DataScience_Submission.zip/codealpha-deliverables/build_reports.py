#!/usr/bin/env python3
"""Build the reviewed CodeAlpha design reports as Markdown, DOCX, and PDF.

The narrative and measured results live in report_content.json. This renderer
does not rerun models or change source data. Run project analyses before using it.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from xml.sax.saxutils import escape

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, Frame, Image, KeepTogether, PageBreak, PageTemplate,
    Paragraph, Spacer, Table, TableStyle,
)

NAVY = "15324D"
TEAL = "007F86"
INK = "253648"
GRAY = "526474"
LIGHT = "EDF5F6"
WHITE = "FFFFFF"
REPORT_DATE = "19 October 2026"
OWNER = "nisa3131"


def inline(text: str) -> str:
    """Escape plain narrative for ReportLab; only **bold** is interpreted."""
    parts = re.split(r"(\*\*.*?\*\*)", str(text))
    return "".join(
        "<b>" + escape(p[2:-2]) + "</b>" if p.startswith("**")
        else escape(p) for p in parts
    )


def add_runs(paragraph, text):
    for part in re.split(r"(\*\*.*?\*\*)", str(text)):
        run = paragraph.add_run(part[2:-2] if part.startswith("**") else part)
        if part.startswith("**"):
            run.bold = True


def image_path(spec, block, project_root):
    path = project_root / spec["repository"] / block["path"]
    if not path.is_file():
        raise FileNotFoundError(f"Report figure is missing: {path}")
    return path


def markdown_blocks(spec, project_root, relative_prefix=""):
    lines = []
    for block in spec["blocks"]:
        kind = block["type"]
        if kind == "heading":
            lines.extend(["", "#" * block.get("level", 2) + " " + block["text"], ""])
        elif kind in {"paragraph", "note"}:
            prefix = "> " if kind == "note" else ""
            lines.extend([prefix + block["text"], ""])
        elif kind == "bullets":
            lines.extend(["- " + item for item in block["items"]] + [""])
        elif kind == "table":
            header = [str(v).replace("\n", "<br>") for v in block["headers"]]
            lines.extend(["| " + " | ".join(header) + " |",
                          "| " + " | ".join("---" for _ in header) + " |"])
            lines.extend("| " + " | ".join(str(x).replace("|", "\\|").replace("\n", "<br>") for x in row) + " |"
                         for row in block["rows"])
            lines.append("")
            if block.get("caption"):
                lines.extend(["*" + block["caption"] + "*", ""])
        elif kind == "figure":
            image_path(spec, block, project_root)
            path = relative_prefix + block["path"]
            lines.extend([f'![{block["caption"]}]({path})', "",
                          "*" + block["caption"] + "*", ""])
        elif kind == "code":
            lines.extend(["```bash", block["text"], "```", ""])
        else:
            raise ValueError(f"Unsupported report block {kind}")
    return lines


def render_markdown(specs, path, project_root, combined):
    lines = ["# " + ("CodeAlpha Data Science — Design Report" if combined else specs[0]["title"]), "",
             f"**Prepared for:** {OWNER}  ",
             f"**Report date:** {REPORT_DATE} (Asia/Dhaka)  ",
             "**Scope:** Four CodeAlpha Data Science tasks" if combined else
             f'**Repository:** `{specs[0]["repository"]}`', "",
             "This report uses the standard layout approved by the user: objectives, data, method, "
             "results, limitations, and reproducibility. All reported findings come from the supplied "
             "datasets and executed project analyses.", ""]
    if combined:
        lines.extend(["## Contents", ""])
        lines.extend(f'{i}. {spec["title"]}' for i, spec in enumerate(specs, 1))
        lines.extend(["", "The internship document requests completion of two or three tasks. This portfolio "
                      "covers all four tasks as requested by the user. GitHub upload and external submission "
                      "status are tracked separately from the analytical findings.", ""])
    for i, spec in enumerate(specs):
        if combined:
            lines.extend(["---", "", f'# {i + 1}. {spec["title"]}', "",
                          f'**Repository:** `{spec["repository"]}`', ""])
        prefix = f'../codealpha-projects/{spec["repository"]}/' if combined else ""
        lines.extend(markdown_blocks(spec, project_root, prefix))
    path.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")


def set_cell_shading(cell, fill):
    props = cell._tc.get_or_add_tcPr()
    shade = OxmlElement("w:shd")
    shade.set(qn("w:fill"), fill)
    props.append(shade)


def setup_docx():
    doc = Document()
    section = doc.sections[0]
    section.page_height, section.page_width = Inches(11.69), Inches(8.27)
    section.top_margin, section.bottom_margin = Inches(.75), Inches(.7)
    section.left_margin, section.right_margin = Inches(.8), Inches(.8)
    for name in ["Normal", "Body Text", "List Bullet"]:
        style = doc.styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(10)
        style.font.color.rgb = RGBColor.from_string(INK)
        style.paragraph_format.space_after = Pt(7)
        style.paragraph_format.line_spacing = 1.15
    for name, size in [("Title", 30), ("Heading 1", 23), ("Heading 2", 15), ("Heading 3", 11)]:
        style = doc.styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(NAVY if name != "Heading 3" else TEAL)
        style.paragraph_format.space_before = Pt(12)
        style.paragraph_format.space_after = Pt(7)
    title_props = doc.styles["Title"].element.find(qn("w:pPr"))
    if title_props is not None:
        for border in list(title_props.findall(qn("w:pBdr"))):
            title_props.remove(border)
    doc.styles["Caption"].font.size = Pt(9)
    doc.styles["Caption"].font.color.rgb = RGBColor.from_string(GRAY)
    header = section.header.paragraphs[0]
    header.text = "CODEALPHA  /  DATA SCIENCE"
    header.style = doc.styles["Caption"]
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.add_run(f"{OWNER}  •  {REPORT_DATE}  •  ").font.size = Pt(8)
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)
    doc.core_properties.author = OWNER
    doc.core_properties.subject = "CodeAlpha Data Science task design and evaluation"
    return doc


def docx_blocks(doc, spec, project_root):
    for block in spec["blocks"]:
        kind = block["type"]
        if kind == "heading":
            doc.add_heading(block["text"], min(block.get("level", 2), 3))
        elif kind in {"paragraph", "note"}:
            p = doc.add_paragraph()
            add_runs(p, block["text"])
            if kind == "note":
                p.paragraph_format.left_indent = Inches(.15)
                for r in p.runs:
                    r.italic = True
                    r.font.color.rgb = RGBColor.from_string(GRAY)
        elif kind == "bullets":
            for item in block["items"]:
                add_runs(doc.add_paragraph(style="List Bullet"), item)
        elif kind == "table":
            table = doc.add_table(rows=1, cols=len(block["headers"]))
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            table.style = "Light Shading Accent 1"
            for i, text in enumerate(block["headers"]):
                cell = table.rows[0].cells[i]
                cell.text = str(text)
                set_cell_shading(cell, NAVY)
                for run in cell.paragraphs[0].runs:
                    run.font.bold = True
                    run.font.color.rgb = RGBColor.from_string(WHITE)
            for row_idx, row in enumerate(block["rows"]):
                cells = table.add_row().cells
                for i, text in enumerate(row):
                    cells[i].text = str(text)
                    if row_idx % 2 == 0:
                        set_cell_shading(cells[i], LIGHT)
                    for para in cells[i].paragraphs:
                        for run in para.runs:
                            run.font.size = Pt(9)
            # Repeat table headers across page breaks.
            props = table.rows[0]._tr.get_or_add_trPr()
            repeat = OxmlElement("w:tblHeader")
            props.append(repeat)
            for row_index, row in enumerate(table.rows):
                row_props = row._tr.get_or_add_trPr()
                row_props.append(OxmlElement("w:cantSplit"))
                for cell in row.cells:
                    for para in cell.paragraphs:
                        para.paragraph_format.keep_together = True
                        para.paragraph_format.keep_with_next = row_index < len(table.rows) - 1
            if block.get("caption"):
                doc.add_paragraph(block["caption"], style="Caption")
        elif kind == "figure":
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.keep_with_next = True
            p.add_run().add_picture(str(image_path(spec, block, project_root)), width=Inches(6.3))
            doc.add_paragraph(block["caption"], style="Caption")
        elif kind == "code":
            p = doc.add_paragraph()
            p.paragraph_format.keep_together = True
            for i, line in enumerate(block["text"].splitlines()):
                run = p.add_run(("\n" if i else "") + line)
                run.font.name = "Consolas"
                run.font.size = Pt(8)
            p.paragraph_format.left_indent = Inches(.15)
        else:
            raise ValueError(kind)


def render_docx(specs, path, project_root, combined):
    doc = setup_docx()
    title = "Data Science\nDesign Report" if combined else specs[0]["title"]
    doc.core_properties.title = title.replace("\n", " ")
    doc.add_paragraph("CODEALPHA INTERNSHIP", style="Subtitle")
    doc.add_heading(title, 0)
    doc.add_paragraph("Four reproducible studies" if combined else "Project design, findings, and reproducibility", style="Subtitle")
    doc.add_paragraph(f"Prepared for {OWNER}\n{REPORT_DATE} · Asia/Dhaka")
    doc.add_paragraph("Standard design report layout approved by the user. Findings use the uploaded datasets "
                      "and measured outputs from the accompanying projects.")
    if combined:
        doc.add_heading("Contents", 2)
        for i, spec in enumerate(specs, 1):
            doc.add_paragraph(f'{i:02d}  {spec["title"]}')
        doc.add_paragraph("The task document asks interns to complete two or three tasks. This portfolio covers "
                          "all four tasks at the user’s request. Repository upload and external submission "
                          "status are tracked separately from analytical results.")
    for i, spec in enumerate(specs):
        heading = doc.add_heading((f'{i + 1:02d}  ' if combined else "") + spec["title"], 1)
        heading.paragraph_format.page_break_before = True
        p = doc.add_paragraph()
        p.add_run("REPOSITORY  ").bold = True
        p.add_run(spec["repository"])
        docx_blocks(doc, spec, project_root)
    doc.save(path)


def pdf_styles():
    font_dir = Path("/usr/share/fonts/truetype/dejavu")
    if (font_dir / "DejaVuSans.ttf").exists():
        for name, file in [("BodyFont", "DejaVuSans.ttf"), ("BodyFont-Bold", "DejaVuSans-Bold.ttf"),
                           ("BodyFont-Oblique", "DejaVuSans-Oblique.ttf")]:
            pdfmetrics.registerFont(TTFont(name, str(font_dir / file)))
        pdfmetrics.registerFontFamily("BodyFont", normal="BodyFont", bold="BodyFont-Bold",
                                      italic="BodyFont-Oblique", boldItalic="BodyFont-Bold")
        font = "BodyFont"
    else:
        font = "Helvetica"
    styles = getSampleStyleSheet()
    for name in ["Normal", "BodyText"]:
        styles[name].fontName = font
        styles[name].fontSize = 9.3
        styles[name].leading = 14
        styles[name].textColor = colors.HexColor("#" + INK)
        styles[name].spaceAfter = 7
    for name, size, leading in [("Title", 32, 39), ("Heading1", 22, 28), ("Heading2", 14, 19), ("Heading3", 11, 16)]:
        styles[name].fontName = font + "-Bold" if font == "BodyFont" else "Helvetica-Bold"
        styles[name].fontSize = size
        styles[name].leading = leading
        styles[name].textColor = colors.HexColor("#" + NAVY)
        styles[name].spaceBefore = 12
        styles[name].spaceAfter = 8
    styles["Title"].alignment = TA_LEFT
    styles.add(ParagraphStyle("Caption2", parent=styles["Normal"], fontSize=8, leading=11,
                              textColor=colors.HexColor("#" + GRAY), spaceBefore=4, spaceAfter=12))
    styles.add(ParagraphStyle("Label", parent=styles["Normal"], fontSize=9, leading=14,
                              textColor=colors.HexColor("#" + TEAL), spaceAfter=14))
    styles.add(ParagraphStyle("TableCell", parent=styles["Normal"], fontSize=8, leading=11, spaceAfter=0))
    styles.add(ParagraphStyle("TableHead", parent=styles["TableCell"], textColor=colors.white,
                              fontName=font + "-Bold" if font == "BodyFont" else "Helvetica-Bold"))
    styles.add(ParagraphStyle("Code2", parent=styles["Normal"], fontName="Courier", fontSize=7.5, leading=11,
                              backColor=colors.HexColor("#" + LIGHT), borderPadding=8, spaceBefore=6, spaceAfter=12))
    styles.add(ParagraphStyle("Bullet2", parent=styles["Normal"], leftIndent=13, firstLineIndent=-9))
    return styles, font


def pdf_blocks(spec, project_root, styles):
    blocks = []
    for block in spec["blocks"]:
        kind = block["type"]
        if kind == "heading":
            blocks.append(Paragraph(inline(block["text"]), styles[f'Heading{min(block.get("level", 2), 3)}']))
        elif kind in {"paragraph", "note"}:
            content = inline(block["text"])
            if kind == "note":
                content = "<i>" + content + "</i>"
            blocks.append(Paragraph(content, styles["Normal"]))
        elif kind == "bullets":
            for item in block["items"]:
                blocks.append(Paragraph("• " + inline(item), styles["Bullet2"]))
        elif kind == "table":
            data = [[Paragraph(inline(v), styles["TableHead"]) for v in block["headers"]]]
            data += [[Paragraph(inline(str(v)), styles["TableCell"]) for v in row] for row in block["rows"]]
            ncols = len(data[0])
            weights = block.get("widths", [1] * ncols)
            width = A4[0] - 100
            col_widths = [width * w / sum(weights) for w in weights]
            table = Table(data, colWidths=col_widths, repeatRows=1, hAlign="LEFT")
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#" + NAVY)),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.HexColor("#" + LIGHT), colors.white]),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("LINEBELOW", (0, -1), (-1, -1), .4, colors.HexColor("#CFDBE2")),
            ]))
            table_block = [table]
            if block.get("caption"):
                table_block.append(Paragraph(inline(block["caption"]), styles["Caption2"]))
            else:
                table_block.append(Spacer(1, 10))
            blocks.append(KeepTogether(table_block))
        elif kind == "figure":
            path = image_path(spec, block, project_root)
            width, height = ImageReader(str(path)).getSize()
            max_width, max_height = A4[0] - 100, 270
            scale = min(max_width / width, max_height / height)
            fig = Image(str(path), width=width * scale, height=height * scale)
            fig.hAlign = "CENTER"
            caption = Paragraph(inline(block["caption"]), styles["Caption2"])
            blocks.append(KeepTogether([Spacer(1, 6), fig, caption]))
        elif kind == "code":
            blocks.append(KeepTogether([Paragraph(escape(block["text"]).replace("\n", "<br/>"), styles["Code2"])]))
        else:
            raise ValueError(kind)
    # Short closing sections stay together so headings and commands do not
    # strand on the previous page while their explanation begins on the next.
    arranged, closing = [], []
    for item in blocks:
        is_closing = (isinstance(item, Paragraph) and item.style.name == "Heading2" and
                      item.getPlainText().startswith(("5  ", "6  ")))
        if is_closing:
            if closing:
                arranged.append(KeepTogether(closing))
            closing = [item]
        elif closing:
            closing.append(item)
        else:
            arranged.append(item)
    if closing:
        arranged.append(KeepTogether(closing))
    return arranged


class ReportDocument(BaseDocTemplate):
    """Add navigation bookmarks without embedding unverified external links."""

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and flowable.style.name == "Heading1":
            title = flowable.getPlainText()
            key = f"project-{self.page}"
            self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(title, key, level=0, closed=False)


def render_pdf(specs, path, project_root, combined):
    styles, font = pdf_styles()
    title = "Data Science<br/>Design Report" if combined else inline(specs[0]["title"])
    doc = ReportDocument(str(path), pagesize=A4, rightMargin=50, leftMargin=50,
                          topMargin=64, bottomMargin=53, title=title.replace("<br/>", " "), author=OWNER)
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="normal", leftPadding=0,
                  bottomPadding=0, rightPadding=0, topPadding=0)

    def draw_page(canvas, document):
        width, height = A4
        canvas.saveState()
        canvas.setFillColor(colors.HexColor("#" + TEAL))
        canvas.rect(0, height - 7, width, 7, fill=1, stroke=0)
        canvas.setFont(font, 7.8)
        canvas.setFillColor(colors.HexColor("#" + GRAY))
        canvas.drawString(50, height - 37, "CODEALPHA  /  DATA SCIENCE")
        canvas.setStrokeColor(colors.HexColor("#D9E5EA"))
        canvas.line(50, 39, width - 50, 39)
        canvas.setFont(font, 7)
        canvas.drawString(50, 26, f"{OWNER}  •  {REPORT_DATE}")
        canvas.drawRightString(width - 50, 26, str(document.page))
        canvas.restoreState()

    doc.addPageTemplates([PageTemplate(id="standard", frames=frame, onPage=draw_page)])
    flow = [Spacer(1, 42), Paragraph("CODEALPHA INTERNSHIP", styles["Label"]),
            Paragraph(title, styles["Title"]), Spacer(1, 14),
            Paragraph("Four reproducible studies" if combined else "Project design, findings, and reproducibility", styles["Heading2"]),
            Spacer(1, 18), Paragraph(f"Prepared for <b>{OWNER}</b><br/>{REPORT_DATE} · Asia/Dhaka", styles["Normal"]),
            Spacer(1, 12), Paragraph("Standard design report layout approved by the user. Findings use the uploaded "
                                    "datasets and measured outputs from the accompanying projects.", styles["Normal"])]
    if combined:
        flow.extend([Spacer(1, 24), Paragraph("Contents", styles["Heading2"])])
        for i, spec in enumerate(specs, 1):
            flow.append(Paragraph(f'{i:02d} &nbsp; {inline(spec["title"])}', styles["Normal"]))
        flow.extend([Spacer(1, 12), Paragraph("The task document requests two or three completed tasks. This portfolio "
                                             "covers all four at the user’s request. GitHub upload and external submission "
                                             "status are tracked separately from the analytical findings.", styles["Normal"])])
    for i, spec in enumerate(specs):
        flow.extend([PageBreak(), Paragraph((f'{i + 1:02d} &nbsp; ' if combined else "") + inline(spec["title"]), styles["Heading1"]),
                     Paragraph("REPOSITORY &nbsp; " + inline(spec["repository"]), styles["Label"])])
        flow.extend(pdf_blocks(spec, project_root, styles))
    doc.build(flow)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve().parent
    parser.add_argument("--content", type=Path, default=here / "report_content.json")
    parser.add_argument("--project-root", type=Path, default=here.parent / "codealpha-projects")
    parser.add_argument("--output", type=Path, default=here)
    args = parser.parse_args()
    content = json.loads(args.content.read_text(encoding="utf-8"))
    specs = content["projects"]
    if len(specs) != 4:
        raise ValueError("The combined CodeAlpha portfolio requires all four completed project specifications.")
    args.output.mkdir(parents=True, exist_ok=True)
    for spec in specs:
        destination = args.output / "individual" / spec["repository"]
        destination.mkdir(parents=True, exist_ok=True)
        render_markdown([spec], destination / "REPORT.md", args.project_root, False)
        render_docx([spec], destination / "report.docx", args.project_root, False)
        render_pdf([spec], destination / "report.pdf", args.project_root, False)
        print(f'Built individual report: {spec["repository"]}')
    base = args.output / "CodeAlpha_DataScience_Design_Report"
    render_markdown(specs, base.with_suffix(".md"), args.project_root, True)
    render_docx(specs, base.with_suffix(".docx"), args.project_root, True)
    render_pdf(specs, base.with_suffix(".pdf"), args.project_root, True)
    print(f"Built combined report: {base.name}")


if __name__ == "__main__":
    main()
