"""Package the verified project commits without nesting the hosted download archive."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
PROJECTS = ROOT.parent / 'codealpha-projects'
ARCHIVE = ROOT / 'CodeAlpha_DataScience_Submission.zip'


def main():
    records = json.loads((ROOT / 'repository-manifest.json').read_text())
    contents = {'README.md': (ROOT / 'SUBMISSION_README.md').read_bytes()}
    bundle_results = []
    for record in records:
        project = PROJECTS / record['repository']
        commit = record['project_commit']
        paths = subprocess.check_output([
            'git', '-C', str(project), 'ls-tree', '-r', '--name-only', '-z', commit
        ]).decode().split('\0')
        for name in filter(None, paths):
            if name.startswith('submission/'):
                continue
            contents[f'codealpha-projects/{project.name}/{name}'] = subprocess.check_output([
                'git', '-C', str(project), 'show', f'{commit}:{name}'
            ])
        bundle = ROOT / 'git-bundles' / record['bundle']
        subprocess.run(['git', '-C', str(project), 'bundle', 'verify', str(bundle)],
                       check=True, capture_output=True)
        heads = subprocess.check_output(['git', 'bundle', 'list-heads', str(bundle)], text=True)
        main_ref = [row.split()[0] for row in heads.splitlines()
                    if row.split()[1] == 'refs/heads/main']
        assert main_ref == [commit], (project.name, main_ref, commit)
        bundle_results.append({'repository': project.name, 'project_commit': commit,
                               'bundle_verified': True, 'bundle_main_matches_project_commit': True})
    (ROOT / 'bundle-validation.json').write_text(json.dumps({'passed': True, 'repositories': bundle_results}, indent=2)+'\n')

    names = [
        'CodeAlpha_DataScience_Design_Report.pdf', 'CodeAlpha_DataScience_Design_Report.docx',
        'CodeAlpha_DataScience_Design_Report.md', 'REPORT_BUILDING.md', 'SUBMISSION_README.md',
        'author_reports.py', 'build_reports.py', 'report_content.json',
        'requirements-reports.txt', 'requirements-report.txt', 'execute_notebooks.py',
        'publish_projects.py', 'build_submission_package.py', 'notebook-validation.json',
        'validation-summary.json', 'report-validation.json', 'repository-manifest.json',
        'github-publication.json', 'bundle-validation.json',
    ]
    sources = [ROOT / name for name in names]
    sources.extend(p for folder in ['individual', 'git-bundles', 'submission-materials']
                   for p in sorted((ROOT / folder).rglob('*')) if p.is_file())
    for path in sources:
        contents['codealpha-deliverables/'+path.relative_to(ROOT).as_posix()] = path.read_bytes()
    manifest = {'archive': ARCHIVE.name, 'files': len(contents),
                'scope': 'Four verified project snapshots, reports and submission materials. The hosted archive is excluded from its own contents.',
                'contents': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                             for name, data in contents.items()]}
    encoded_manifest = (json.dumps(manifest, indent=2)+'\n').encode()
    contents['package-manifest.json'] = encoded_manifest
    temporary = ARCHIVE.with_name('submission-build.zip')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in contents.items():
            archive.writestr(name, data)
    with zipfile.ZipFile(temporary) as archive:
        assert archive.testzip() is None
        for name, data in contents.items():
            assert archive.read(name) == data
        assert len([p for p in archive.namelist() if p.startswith('codealpha-projects/') and p.endswith('/analysis.ipynb')]) == 4
        assert 'codealpha-deliverables/submission-materials/SUBMISSION_CHECKLIST.pdf' in archive.namelist()
    temporary.replace(ARCHIVE)
    (ROOT / 'package-manifest.json').write_bytes(encoded_manifest)
    sha = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    ARCHIVE.with_suffix('.zip.sha256').write_text(sha+'  '+ARCHIVE.name+'\n')
    print(json.dumps({'archive': str(ARCHIVE), 'entries': len(contents),
                      'size_bytes': ARCHIVE.stat().st_size, 'sha256': sha}))


if __name__ == '__main__':
    main()
