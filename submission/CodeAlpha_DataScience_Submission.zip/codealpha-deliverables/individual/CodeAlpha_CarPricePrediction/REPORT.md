# Car Price Prediction with Machine Learning

**Prepared for:** nisa3131  
**Report date:** 19 October 2026 (Asia/Dhaka)  
**Repository:** `CodeAlpha_CarPricePrediction`

This report uses the standard layout approved by the user: objectives, data, method, results, limitations, and reproducibility. All reported findings come from the supplied datasets and executed project analyses.


## 1  Objective

Predict Selling_Price from the supplied historical vehicle features using a regression workflow with cleaning, feature engineering, preprocessing, model selection, and held-out evaluation. Although the assignment calls this car price prediction, the supplied file also includes motorcycles and scooters, so interpretation covers used vehicles.


## 2  Data and provenance

Input: the user-supplied archive (2).zip, containing car data.csv. The task document links to https://www.kaggle.com/datasets/vijayaadithyanvg/car-price-predictionused-cars. That link is cited as the assignment’s dataset reference; these analyses use the uploaded files rather than a new download. Original collection details and redistribution licensing were not independently verified. No dataset license is asserted.

| Attribute | Observed data / treatment |
| --- | --- |
| Records | 301 raw; 2 exact duplicates removed; 299 retained |
| Vehicle groups | 97 normalized vehicle names |
| Year range | 2003–2018 |
| Missing values | None in the supplied file |
| Inputs | Name, year, present price, distance driven, fuel, selling type, transmission, and owners |
| Price units | Original dataset units; currency and scale not independently verified |

Normalize categorical case and whitespace. Vehicle_Age = 2018 − Year uses the maximum year in this historical file as a fixed reference; it is neither the verified collection date nor the vehicle’s age today. Keep the 500,000 km outlier and rare fuel/ownership values rather than removing them silently. Horsepower, brand goodwill, accident history, and condition are absent, so no such fields are invented.


## 3  Method and evaluation

After deduplication, seeded GroupShuffleSplit holds out 20% of normalized name groups: 229 training rows across 77 names and 70 test rows across 20 names. No name overlaps. The group fraction does not force a 20% row fraction. This evaluates generalization to unseen named vehicle models, which is more demanding than random listings of familiar models.

A ColumnTransformer pipeline applies median imputation and scaling to numeric features, and most-frequent imputation plus one-hot encoding to categorical features. All learned preprocessing is fit within training folds; unknown categories are ignored safely. The numeric features are historical age, present price, distance driven, and owners.

A median baseline, Ridge, random forest, and gradient boosting use the same five training-only GroupKFold splits. Predeclared grids select the lowest mean grouped CV MAE. The winning model and baseline are then evaluated once on the untouched held-out names. Post-selection test permutation importance is descriptive and does not select or tune the model.


## 4  Results and interpretation

| Candidate | CV MAE | Fold SD |
| --- | --- | --- |
| random forest | 0.9258 | 0.4306 |
| gradient boosting | 0.9504 | 0.5795 |
| ridge | 1.0617 | 0.2976 |
| dummy median | 3.2631 | 0.9471 |

*Training-only group-aware comparison. MAE and SD use dataset price units; fold SD is not a confidence interval.*

**Selected model: random forest**, with 300 trees, unrestricted depth, and minimum leaf size 3. Mean grouped CV MAE is 0.9258.

| Held-out model | MAE | RMSE | R² |
| --- | --- | --- | --- |
| Selected random forest | 2.0562 | 3.3528 | 0.5839 |
| Median baseline | 3.4954 | 5.4453 | -0.0975 |

*Evaluation on 70 rows from 20 unseen named models. Lower error and higher R² are better.*

Test MAE is 41.2% lower than the median baseline. The gap between training CV and test errors is material and should temper expectations about transfer to new vehicle groups. MAE is average absolute error; RMSE penalizes larger errors more heavily; R² is a split-specific squared-error comparison with the test mean.

![Figure 1. Predictions and residuals for held-out vehicle names. Individual errors remain substantial despite improvement over the baseline.](outputs/charts/heldout_predictions_and_residuals.png)

*Figure 1. Predictions and residuals for held-out vehicle names. Individual errors remain substantial despite improvement over the baseline.*

![Figure 2. Post-selection importance: increase in held-out MAE after input shuffling, with 20-repeat variation. Correlated inputs may share or mask importance.](outputs/charts/permutation_importance.png)

*Figure 2. Post-selection importance: increase in held-out MAE after input shuffling, with 20-repeat variation. Correlated inputs may share or mask importance.*

Present_Price has the largest measured permutation effect: 2.787 dataset price units of added MAE on average. This is predictive association, not a causal effect. Car_Name importance is zero by construction because every held-out name is unseen and its one-hot categories are unknown. Present_Price would be useful operationally only if its definition and timestamp were verified and the value were available when a prediction is requested.


## 5  Limitations and next steps

- The historical convenience sample is small and mixes vehicle types. Location, collection date, currency, condition, service history, and accident history are unverified or missing.
- The name-based holdout estimates transfer to unseen names within this file. It does not establish current-market accuracy, transport to a new country, or a production valuation service.
- Grouping and exact deduplication reduce direct leakage; hidden repeated listings under different names cannot be ruled out. One seeded holdout is not a population uncertainty interval.
- Collect representative, dated and permissioned listings, verify units and predictor availability, and define a deployment-specific validation protocol before using predictions for valuation.


## 6  Reproducibility

Validation recorded on 19 October 2026: the delivered notebook executed 4 code cells with 0 recorded errors. The analysis pipeline and its built-in data/evaluation checks completed successfully. The project’s 4 unit tests also passed.

Install the pinned requirements and rerun from the repository root. The notebook calls the same analysis pipeline.

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python analysis.py
python -m unittest discover -s tests -v
```

outputs/metrics.json and data_audit.json record the source SHA-256, duplicate policy, split counts, versions, parameters, and errors. split_assignments.csv, cv_results.csv, heldout_predictions.csv, and permutation_importance.csv expose the evaluation trail. Four chart PNGs are generated. The saved model.joblib is fit on training data only; only load serialized models from a trusted source.
