"""Execute each deliverable notebook in its project directory and save real outputs."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import json
import os
import sys
import time

BASE = Path(__file__).resolve().parent.parent / 'codealpha-projects'
TOOLS = Path(sys.prefix)
CACHE = Path(__file__).resolve().parent / '.cache'
KERNEL_NAME = 'codealpha'
for variable, location in {
    'JUPYTER_PATH': TOOLS / 'share/jupyter',
    'JUPYTER_RUNTIME_DIR': CACHE / 'runtime',
    'IPYTHONDIR': CACHE / 'ipython',
    'XDG_CACHE_HOME': CACHE,
    'MPLCONFIGDIR': CACHE / 'mplconfig',
}.items():
    if variable != 'JUPYTER_PATH':
        location.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault(variable, str(location))

import nbformat
from nbclient import NotebookClient


def execute(project):
    path = project / 'analysis.ipynb'
    notebook = nbformat.read(path, as_version=4)
    nbformat.validate(notebook)
    started = time.time()
    client = NotebookClient(
        notebook, kernel_name=KERNEL_NAME, timeout=600,
        resources={'metadata': {'path': str(project)}},
        allow_errors=False,
    )
    client.execute()
    code_cells = [cell for cell in notebook.cells if cell.cell_type == 'code']
    assert code_cells and all(cell.execution_count is not None for cell in code_cells)
    assert all(output.output_type != 'error' for cell in code_cells for output in cell.outputs)
    nbformat.validate(notebook)
    nbformat.write(notebook, path)
    result = {
        'project': project.name, 'executed_code_cells': len(code_cells),
        'errors': 0, 'elapsed_seconds': round(time.time() - started, 3),
    }
    print(json.dumps(result), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', type=Path, default=BASE)
    parser.add_argument('--kernel-name', default=KERNEL_NAME)
    args = parser.parse_args()
    BASE = args.project_root.resolve()
    KERNEL_NAME = args.kernel_name
    projects = sorted(BASE.glob('CodeAlpha_*'))
    assert len(projects) == 4
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(execute, projects))
    (Path(__file__).parent / 'notebook-validation.json').write_text(
        json.dumps({'passed': True, 'notebooks': results}, indent=2) + '\n'
    )
