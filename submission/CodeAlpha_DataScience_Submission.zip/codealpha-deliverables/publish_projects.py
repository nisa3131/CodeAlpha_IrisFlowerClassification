"""Create the four approved repositories and push committed work using gh authentication.

New repositories require GitHub API access and authenticated gh access.
--existing-only uses the existing Git connection and makes no API calls.
Never reads or stores credential values. Existing remote content is preserved.
"""
from pathlib import Path
import argparse
import json
import subprocess
import sys

NAMES = [
    'CodeAlpha_IrisFlowerClassification',
    'CodeAlpha_UnemploymentAnalysis',
    'CodeAlpha_CarPricePrediction',
    'CodeAlpha_SalesPrediction',
]
OWNER = 'nisa3131'


def command(args, *, cwd=None, input_text=None, check=True):
    result = subprocess.run(args, cwd=cwd, input=input_text, text=True,
                            capture_output=True, timeout=120)
    if check and result.returncode:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or f'{args[0]} failed')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--projects-root', type=Path,
                        default=Path(__file__).resolve().parent.parent / 'codealpha-projects')
    parser.add_argument('--visibility', choices=['public', 'private'], required=True)
    parser.add_argument('--existing-only', action='store_true',
                        help='Use Git only for repositories already created by the user; no API calls or visibility changes.')
    args = parser.parse_args()
    if not args.existing_only:
        identity = json.loads(command(['gh', 'api', 'user']).stdout)['login']
        if identity.casefold() != OWNER.casefold():
            raise RuntimeError(f'Authenticate as {OWNER} before creating these personal repositories.')

    for name in NAMES:
        root = args.projects_root.resolve() / name
        if not root.is_dir():
            raise RuntimeError(f'Missing project directory: {root}')
        if not (root / '.git').exists():
            bundle = Path(__file__).resolve().parent / 'git-bundles' / f'{name}.bundle'
            if not bundle.is_file():
                raise RuntimeError(f'Missing Git metadata and bundle for {name}')
            command(['git', 'init', '-b', 'main', str(root)])
            command(['git', 'fetch', str(bundle), 'main'], cwd=root)
            # Restore only the index from the supplied commit; never replace working files.
            command(['git', 'reset', '--mixed', 'FETCH_HEAD'], cwd=root)
        if command(['git', 'status', '--porcelain'], cwd=root).stdout.strip():
            raise RuntimeError(f'{name} has uncommitted files; preserve and review them first.')
        if command(['git', 'branch', '--show-current'], cwd=root).stdout.strip() != 'main':
            raise RuntimeError(f'{name} must be on its reviewed main branch.')
        remote = f'https://github.com/{OWNER}/{name}.git'
        existing = command(['git', 'remote', 'get-url', 'origin'], cwd=root, check=False)
        if existing.returncode:
            command(['git', 'remote', 'add', 'origin', remote], cwd=root)
        elif existing.stdout.strip() != remote:
            raise RuntimeError(f'{name} has a different origin; it was not changed.')

        if not args.existing_only:
            response = command(['gh', 'api', f'repos/{OWNER}/{name}'], check=False)
            if response.returncode:
                if 'HTTP 404' not in response.stderr:
                    raise RuntimeError(response.stderr.strip())
                payload = {'name': name, 'private': args.visibility == 'private',
                           'description': name.replace('CodeAlpha_', 'CodeAlpha Data Science: '),
                           'auto_init': False}
                command(['gh', 'api', '--method', 'POST', 'user/repos', '--input', '-'],
                        input_text=json.dumps(payload))
            else:
                actual_private = json.loads(response.stdout)['private']
                if actual_private != (args.visibility == 'private'):
                    raise RuntimeError(f'{name} already exists with different visibility; it was not changed.')

        refs = command(['git', 'ls-remote', 'origin'], cwd=root).stdout.strip()
        local_head = command(['git', 'rev-parse', 'HEAD'], cwd=root).stdout.strip()
        if refs:
            main_refs = [line.split()[0] for line in refs.splitlines()
                         if line.split()[1] == 'refs/heads/main']
            if len(main_refs) != 1:
                raise RuntimeError(f'{name} contains remote history without a matching main branch; no overwrite was attempted.')
            if main_refs[0] != local_head:
                command(['git', 'fetch', 'origin', 'main'], cwd=root)
                ancestor = command(['git', 'merge-base', '--is-ancestor', 'FETCH_HEAD', 'HEAD'],
                                   cwd=root, check=False)
                if ancestor.returncode:
                    raise RuntimeError(f'{name} contains divergent remote history; no overwrite was attempted.')
        command(['git', 'push', '-u', 'origin', 'main'], cwd=root)
        check_head = command(['git', 'ls-remote', 'origin', 'refs/heads/main'], cwd=root).stdout.split()
        if not check_head or check_head[0] != local_head:
            raise RuntimeError(f'Could not verify the pushed commit for {name}')
        print(f'Pushed and verified commit at https://github.com/{OWNER}/{name}', flush=True)
        if args.existing_only:
            print('Repository visibility was selected by its owner and was not checked through the API.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, subprocess.TimeoutExpired) as error:
        print(f'Publishing stopped: {error}', file=sys.stderr)
        sys.exit(1)
