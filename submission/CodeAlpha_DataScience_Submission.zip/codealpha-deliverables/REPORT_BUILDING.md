# Design report artifacts

The user approved a standard design report layout after the requested template link could not be opened: objectives, data, method, results, limitations, and reproducibility. The reports use measured project outputs, actual generated charts, and the recorded notebook execution results. They do not claim GitHub publication or external internship submission.

The combined report is available as `CodeAlpha_DataScience_Design_Report.pdf`, `.docx`, and `.md`. The editable DOCX and standalone PDF contain embedded charts. Each project also receives `REPORT.md`, `report/report.pdf`, and `report/report.docx`.

## Rebuild

Keep `codealpha-deliverables/` and `codealpha-projects/` as sibling directories. First rerun each project's analysis and notebook validation. From this directory:

```bash
python -m pip install -r requirements-reports.txt
python author_reports.py
python build_reports.py
```

`author_reports.py` reads each project's JSON/CSV outputs and `notebook-validation.json`, and writes `report_content.json`. Its narrative describes the reviewed methods in the delivered source; review that narrative after changing an analysis. The test counts in the narrative correspond to the successful delivery validation recorded in `validation-summary.json`; update the evidence if changing a test suite.

`build_reports.py` renders the structured content as Markdown, DOCX, and PDF. It writes individual reports under `individual/<repository>/`; copy their `REPORT.md` to the corresponding repository root and their PDF/DOCX files to that repository's `report/` directory after regeneration. Combined Markdown links use the sibling project layout. Individual Markdown links assume placement at the project root.

The renderer preserves source CSVs, project code, and analytical outputs. DejaVu Sans is used when available for PDF text, with a standard PDF font fallback. DOCX appearance can vary slightly by the word processor and installed fonts. The delivered DOCX was opened and converted with LibreOffice for a layout check; the independently generated PDF is the fixed-layout sharing artifact.

## Evidence and provenance

- `report-validation.json` records final report page counts, text-bound checks, embedded figures, and the combined DOCX rendering check.
- `notebook-validation.json` records successful execution of all four delivered notebooks.
- The individual `outputs/metrics.json`, data audits, prediction tables, and CV tables remain the analytical source of truth.
- Both uploaded task PDFs were byte-identical (SHA-256 `8ae8cd7c21e41b225fa9d50c0c57f73202930ae0c5c6674e36dee04992e43d01`). The user requested all four projects although the document requires a minimum of two or three.
- The actual datasets come from the uploaded archives. Kaggle URLs in the reports are the references linked by the assignment, not evidence of a fresh download or verified redistribution license.

LinkedIn status/video posts and the internship submission form are external steps and were not performed by report generation.
