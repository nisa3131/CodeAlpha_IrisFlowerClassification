#!/usr/bin/env python3
"""Compose report_content.json from measured project outputs and reviewed methods."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

NOTEBOOK_VALIDATION = {}


def p(text):
    return {"type": "paragraph", "text": text}


def h(text):
    return {"type": "heading", "text": text, "level": 2}


def bullets(*items):
    return {"type": "bullets", "items": list(items)}


def table(headers, rows, caption=None, widths=None):
    result = {"type": "table", "headers": headers, "rows": rows}
    if caption:
        result["caption"] = caption
    if widths:
        result["widths"] = widths
    return result


def figure(path, caption):
    return {"type": "figure", "path": "outputs/" + path, "caption": caption}


def load(root, repository, filename="metrics.json"):
    return json.loads((root / repository / "outputs" / filename).read_text())


def source(archive, files, url):
    return p(f"Input: the user-supplied {archive}, containing {files}. The task document links to {url}. "
             "That link is cited as the assignment’s dataset reference; these analyses use the uploaded "
             "files rather than a new download. Original collection details and redistribution licensing "
             "were not independently verified. No dataset license is asserted.")


def reproducibility(extra, repository, tests=0):
    record = NOTEBOOK_VALIDATION[repository]
    validation = (f'Validation recorded on 19 October 2026: the delivered notebook executed '
                  f'{record["executed_code_cells"]} code cells with {record["errors"]} recorded errors. '
                  "The analysis pipeline and its built-in data/evaluation checks completed successfully.")
    if tests:
        validation += f" The project’s {tests} unit tests also passed."
    commands = ("python -m venv .venv\n. .venv/bin/activate\n"
                "python -m pip install -r requirements.txt\npython analysis.py")
    if tests:
        commands += "\npython -m unittest discover -s tests -v"
    return [h("6  Reproducibility"), p(validation),
            p("Install the pinned requirements and rerun from the repository root. The notebook "
              "calls the same analysis pipeline."),
            {"type": "code", "text": commands},
            p(extra)]


def iris(root):
    repo = "CodeAlpha_IrisFlowerClassification"
    m, a = load(root, repo), load(root, repo, "data_audit.json")
    selected = next(x for x in m["model_selection"] if x["model"] == m["selected_model"])
    species_rows = []
    for name in m["class_order"]:
        r = m["test"]["classification_report"][name]
        species_rows.append([name.removeprefix("Iris-"), str(int(r["support"])),
                             f'{r["precision"]:.3f}', f'{r["recall"]:.3f}', f'{r["f1-score"]:.3f}'])
    blocks = [
        h("1  Objective"),
        p("Classify setosa, versicolor, and virginica flowers from sepal length, sepal width, "
          "petal length, and petal width. The task covers supervised classification, preprocessing, "
          "model comparison, and evaluation on held-out examples."),
        h("2  Data and provenance"),
        source("archive.zip", "Iris.csv", "https://www.kaggle.com/datasets/saurabh00007/iriscsv"),
        table(["Attribute", "Observed data / treatment"], [
            ["Observations", f'{a["rows"]}; 50 per species'],
            ["Predictors", "Four flower measurements in centimetres; Id excluded"],
            ["Data quality", "No missing values or duplicate complete rows"],
            ["Repeated measurements", f'{a["duplicate_measurement_rows"]} repeated measurement rows; {a["unique_measurement_groups"]} unique measurement groups'],
            ["Duplicate treatment", "Retain observations; keep identical measurement groups together in every split"],
        ], widths=[1, 2.5]),
        p("Identical measurements can represent separate flowers, so they are retained. Their group "
          "identity is used for both the train/test partition and cross-validation to prevent the "
          "same measurement vector appearing on both sides. No identical measurement group has "
          "conflicting species labels."),
        h("3  Method and evaluation"),
        p(f'With random seed {m["seed"]}, the first fold from a shuffled five-fold StratifiedGroupKFold '
          f'creates {m["split"]["train_rows"]} training and {m["split"]["test_rows"]} held-out observations. '
          "Each held-out species has 10 examples, and no measurement group crosses the partition. "
          "Group constraints make stratification approximate in general."),
        p("Four candidates are compared: a most-frequent-class baseline, logistic regression, "
          "k-nearest neighbours, and a radial-basis support vector classifier. Numeric scaling is "
          "inside each estimator’s pipeline and therefore fit only on the training portion of each fold. "
          "Predefined grids are C = 0.1, 1, 10 for logistic regression and SVM, and k = 3, 5, 7 for neighbours."),
        p("Training-only, five-fold group-aware cross-validation selects hyperparameters using mean "
          "macro F1. Model-level ties use mean CV accuracy and then model name. The winner is fit on "
          "the full training partition and evaluated once on the held-out partition. The test score "
          "does not choose the model."),
        h("4  Results and interpretation"),
        table(["Candidate", "CV macro F1\nmean ± SD", "CV accuracy"], [
            [x["model"].replace("_", " "), f'{x["mean_cv_macro_f1"]:.4f} ± {x["std_cv_macro_f1"]:.4f}',
             f'{x["mean_cv_accuracy"]:.4f}'] for x in m["model_selection"]
        ], "Training cross-validation scores. The standard deviation describes variation across five folds, not a confidence interval.", [1.6, 1.3, .8]),
        p(f'**Selected model: logistic regression (C = {m["selected_parameters"]["classifier__C"]:g}).** '
          f'Its mean CV macro F1 is {selected["mean_cv_macro_f1"]:.4f}. Held-out accuracy and macro F1 are '
          f'{m["test"]["accuracy"]:.3f} and {m["test"]["macro_f1"]:.3f}, respectively. The most-frequent '
          f'baseline reaches {m["baseline_test"]["accuracy"]:.3f} accuracy and '
          f'{m["baseline_test"]["macro_f1"]:.3f} macro F1.'),
        table(["Species", "Test n", "Precision", "Recall", "F1"], species_rows, widths=[1.3, .7, .9, .9, .9]),
        figure("petal_measurements.png", "Figure 1. Descriptive petal measurements in the supplied dataset. Setosa is visibly separated; versicolor and virginica overlap more."),
        figure("confusion_matrix.png", "Figure 2. Held-out confusion matrix for the CV-selected model. All 30 test observations are correctly classified in this split."),
        h("5  Limitations and next steps"),
        bullets("A perfect score on 30 held-out examples has substantial sampling uncertainty. It does not establish performance on flowers from new locations, instruments, or populations.",
                "Grouping identical vectors reduces direct duplicate leakage; unrecorded biological or collection relationships may still remain.",
                "The labels and measurements are not independently verified. This is an educational model, with no external validation or deployment assessment.",
                "The next evaluation should use an independently collected, well-documented flower dataset and report uncertainty before relying on predictions operationally."),
    ]
    blocks += reproducibility("outputs/metrics.json records versions, split sizes, selected parameters, and per-class evaluation. "
                              "outputs/data_audit.json records the source SHA-256 and quality checks. "
                              "split_assignments.csv and cv_results.csv expose group membership and every tried configuration; "
                              "test_predictions.csv records held-out outcomes. The final estimator is fit on training data only.", repo, tests=2)
    return {"title": "Iris Flower Classification", "repository": repo, "blocks": blocks}


def unemployment(root):
    repo = "CodeAlpha_UnemploymentAnalysis"
    m = load(root, repo)
    q = m["data_quality"]
    panel = m["state_paired_panel"]
    means = panel["means"]
    rural_urban = m["historical_january_june_matched_comparison"]
    patterns = m["observed_2019_within_year_pattern"]
    blocks = [
        h("1  Objective"),
        p("Clean and explore the supplied unemployment data, describe time and regional patterns "
          "around the Covid-19 disruption, assess what the short series can say about seasonality, "
          "and identify policy questions supported by the evidence. This is a descriptive analysis."),
        h("2  Data and provenance"),
        source("archive (1).zip", "Unemployment in India.csv and Unemployment_Rate_upto_11_2020.csv",
               "https://www.kaggle.com/datasets/gokulrajkmv/unemployment-in-india"),
        table(["Dataset", "Raw / clean rows", "Observed coverage"], [
            ["Historical state–area", f'{q["historical_state_area"]["raw_rows"]} / {q["historical_state_area"]["clean_rows"]}',
             "May 2019–June 2020; 28 states/territories; Rural and Urban observations"],
            ["2020 state", f'{q["2020_state"]["raw_rows"]} / {q["2020_state"]["clean_rows"]}',
             "January–October 2020; 27 states/territories; macro-region labels"],
        ], widths=[1.2, 1, 2.4]),
        p("The filename ending in 11_2020 does not establish November coverage: the last observed month "
          "is October. The two files remain separate because their overlapping dates and different "
          "granularities would otherwise create double counting. No rural counterpart is invented for "
          "historical Chandigarh, which has only Urban records."),
        h("3  Cleaning and comparison design"),
        p("Strip headers and text, parse monthly dates and numeric values strictly, standardize frequency "
          "labels, and rename the repeated Region field to macro_region in the 2020 file. Remove only "
          f'{q["historical_state_area"]["fully_blank_rows_removed"]} fully blank historical rows. '
          "Do not impute rates. Required fields, finite values, percentage bounds, integral employment "
          "counts, unique observation keys, and complete comparison panels are checked."),
        p(f'The historical entity-month grid has {q["historical_state_area"]["missing_entity_month_cells"]} '
          f'missing cells and the 2020 state grid has {q["2020_state"]["missing_entity_month_cells"]}. '
          "These are documented rather than filled. Source coordinate labels appear reversed because "
          "the latitude-labeled values exceed 90 degrees; they are preserved with explicit source labels "
          "and are not used for geographic maps."),
        p(f'The main comparison uses the same {panel["n_states"]} complete states/territories across '
          "January–March (reference), April–May (initial disruption), and August–October (later period). "
          "Jammu & Kashmir and Sikkim are excluded for incomplete coverage. First average months within "
          "each state, then average states with equal weight. The balanced monthly trend uses the same "
          "states. Historical rural–urban comparisons require 20 common states with both areas observed "
          "in every relevant month; the full 14-month trend and January–June period panel are explicitly checked."),
        {"type": "note", "text": "All aggregate rates in this report are unweighted state or matched state–area means. They are not official population-weighted national rates. Rate differences are percentage points (pp). The reference period is descriptive; March may already contain pandemic disruption."},
        h("4  Results and policy interpretation"),
        table(["Balanced 25-state measure", "Jan–Mar", "Apr–May", "Aug–Oct"], [
            ["Unemployment rate (%)", f'{means["pre_covid_rate_pct"]:.2f}', f'{means["first_wave_rate_pct"]:.2f}', f'{means["later_recovery_rate_pct"]:.2f}'],
            ["Labour participation (%)", f'{means["pre_covid_lpr_pct"]:.2f}', f'{means["first_wave_lpr_pct"]:.2f}', f'{means["later_recovery_lpr_pct"]:.2f}'],
        ], "Equal state weights and the same states in each period.", [2, 1, 1, 1]),
        p(f'Mean unemployment rises by **{means["first_wave_change_pp"]:.2f} pp** in April–May and is '
          f'{abs(means["later_recovery_change_from_pre_pp"]):.2f} pp below the reference in August–October. '
          f'The balanced monthly peak is May 2020 at {panel["peak_balanced_rate_pct"]:.2f}%. '
          f'{panel["states_above_pre_covid_in_later_recovery"]} of {panel["n_states"]} states remain above '
          "their own reference rate in the later period. Participation also falls and does not return "
          "to its reference mean, so a lower unemployment percentage alone does not establish full labour-market recovery."),
        figure("charts/state_monthly_trends.png", "Figure 1. Balanced 2020 state means for unemployment and labour participation. These show timing and association, not a causal pandemic effect."),
        table(["Largest observed increases", "Apr–May minus Jan–Mar (pp)"], [
            [x["state"], f'{x["first_wave_change_pp"]:.2f}'] for x in panel["largest_first_wave_increases"]
        ], "Descriptive equal-period comparisons within each complete state; no survey uncertainty estimates are supplied.", [1.7, 2]),
        table(["Matched historical area", "Jan–Mar %", "Apr–May %", "June %"], [
            [x["area"], f'{x["pre_covid_rate_pct"]:.2f}', f'{x["first_wave_rate_pct"]:.2f}', f'{x["june_rate_pct"]:.2f}']
            for x in rural_urban["area_means"]
        ], "Separate historical dataset; 20 same states per area in all comparison months.", [1.8, 1, 1, 1]),
        p(f'The matched Urban-minus-Rural gap is '
          f'{rural_urban["mean_urban_minus_rural_gaps_pp"]["pre_covid_urban_minus_rural_pp"]:.2f} pp before '
          f'the disruption, {rural_urban["mean_urban_minus_rural_gaps_pp"]["first_wave_urban_minus_rural_pp"]:.2f} pp '
          f'in April–May, and {rural_urban["mean_urban_minus_rural_gaps_pp"]["june_urban_minus_rural_pp"]:.2f} pp '
          "in June. These comparisons describe the observed matched states rather than every rural or urban resident."),
        figure("charts/rural_urban_trends.png", "Figure 2. Historical rural and urban means over a common, complete state panel. The short series supports observed fluctuations, not a recurring seasonal cycle."),
        p(f'Within May–December 2019, the balanced rural series is highest in October '
          f'({patterns["Rural"]["highest_rate_pct"]:.2f}%) and lowest in May '
          f'({patterns["Rural"]["lowest_rate_pct"]:.2f}%); the urban series is highest in September '
          f'({patterns["Urban"]["highest_rate_pct"]:.2f}%) and lowest in June '
          f'({patterns["Urban"]["lowest_rate_pct"]:.2f}%). With only 14 historical and 10 state-series '
          "months, these are within-year patterns. Several comparable years are needed to distinguish "
          "seasonality from trend, sampling variation, and exceptional disruption."),
        bullets("Policy direction: monitor unemployment, participation, and employment together. The simultaneous rate rise and participation fall motivate rapid access to income support and employment services during sudden disruptions.",
                "Use local monitoring and verified affected-labour-force sizes to plan support. Differences across states and rural–urban panels motivate further investigation; an equal-state mean alone is insufficient for allocating national funds.",
                "Check access to work and income protection in both rural and urban areas. Occupation and migration explanations require additional data because those fields are absent.",
                "Obtain longer series, survey weights, sample sizes, and policy-exposure information before evaluating a particular program’s effectiveness."),
        h("5  Limitations and next steps"),
        p("There is no control group, identified counterfactual, policy-exposure measure, survey weight, "
          "sample size, or standard error. Causality and uncertainty intervals cannot be inferred from "
          "these files. Complete-panel exclusions limit coverage; survey methodology may differ across "
          "the two files. No predictive model, seasonal decomposition, official national estimate, or "
          "causal pandemic effect is claimed."),
    ]
    blocks += reproducibility("outputs/metrics.json records both source SHA-256 hashes, cleaning counts, complete panels, "
                              "period means, and validation outcomes. Cleaned CSVs, missing-observation tables, "
                              "entity/month coverage, matched comparisons, and six figures preserve the audit trail. "
                              "No network is needed for analysis. --data-dir and --output-dir support alternate local paths.", repo)
    return {"title": "Unemployment Analysis with Python", "repository": repo, "blocks": blocks}


def car(root):
    repo = "CodeAlpha_CarPricePrediction"
    m = load(root, repo)
    a, split = m["data"], m["split"]
    winner = m["test_metrics"][m["selected_model"]]
    baseline = m["test_metrics"]["dummy_median"]
    selected_cv = next(x for x in m["cross_validation"] if x["model"] == m["selected_model"])
    with (root / repo / "outputs" / "permutation_importance.csv").open() as f:
        importance = list(csv.DictReader(f))
    blocks = [
        h("1  Objective"),
        p("Predict Selling_Price from the supplied historical vehicle features using a regression "
          "workflow with cleaning, feature engineering, preprocessing, model selection, and held-out "
          "evaluation. Although the assignment calls this car price prediction, the supplied file "
          "also includes motorcycles and scooters, so interpretation covers used vehicles."),
        h("2  Data and provenance"),
        source("archive (2).zip", "car data.csv", "https://www.kaggle.com/datasets/vijayaadithyanvg/car-price-predictionused-cars"),
        table(["Attribute", "Observed data / treatment"], [
            ["Records", f'{a["raw_rows"]} raw; {a["exact_duplicates_removed"]} exact duplicates removed; {a["rows_after_deduplication"]} retained'],
            ["Vehicle groups", f'{a["normalized_vehicle_name_count"]} normalized vehicle names'],
            ["Year range", f'{a["dataset_year_range"][0]}–{a["dataset_year_range"][1]}'],
            ["Missing values", "None in the supplied file"],
            ["Inputs", "Name, year, present price, distance driven, fuel, selling type, transmission, and owners"],
            ["Price units", "Original dataset units; currency and scale not independently verified"],
        ], widths=[1, 2.7]),
        p(f'Normalize categorical case and whitespace. Vehicle_Age = {a["reference_year"]} − Year '
          "uses the maximum year in this historical file as a fixed reference; it is neither the "
          "verified collection date nor the vehicle’s age today. Keep the 500,000 km outlier and "
          "rare fuel/ownership values rather than removing them silently. Horsepower, brand goodwill, "
          "accident history, and condition are absent, so no such fields are invented."),
        h("3  Method and evaluation"),
        p(f'After deduplication, seeded GroupShuffleSplit holds out 20% of normalized name groups: '
          f'{split["train_rows"]} training rows across {split["train_groups"]} names and '
          f'{split["test_rows"]} test rows across {split["test_groups"]} names. No name overlaps. '
          "The group fraction does not force a 20% row fraction. This evaluates generalization to "
          "unseen named vehicle models, which is more demanding than random listings of familiar models."),
        p("A ColumnTransformer pipeline applies median imputation and scaling to numeric features, "
          "and most-frequent imputation plus one-hot encoding to categorical features. All learned "
          "preprocessing is fit within training folds; unknown categories are ignored safely. The "
          "numeric features are historical age, present price, distance driven, and owners."),
        p("A median baseline, Ridge, random forest, and gradient boosting use the same five training-only "
          "GroupKFold splits. Predeclared grids select the lowest mean grouped CV MAE. The winning "
          "model and baseline are then evaluated once on the untouched held-out names. Post-selection "
          "test permutation importance is descriptive and does not select or tune the model."),
        h("4  Results and interpretation"),
        table(["Candidate", "CV MAE", "Fold SD"], [
            [x["model"].replace("_", " "), f'{x["cv_mae_mean"]:.4f}', f'{x["cv_mae_std"]:.4f}']
            for x in sorted(m["cross_validation"], key=lambda v: v["cv_mae_mean"])
        ], "Training-only group-aware comparison. MAE and SD use dataset price units; fold SD is not a confidence interval.", [1.8, 1, 1]),
        p(f'**Selected model: random forest**, with 300 trees, unrestricted depth, and minimum leaf size '
          f'{m["selected_parameters"]["model__min_samples_leaf"]}. Mean grouped CV MAE is '
          f'{selected_cv["cv_mae_mean"]:.4f}.'),
        table(["Held-out model", "MAE", "RMSE", "R²"], [
            ["Selected random forest", f'{winner["mae"]:.4f}', f'{winner["rmse"]:.4f}', f'{winner["r2"]:.4f}'],
            ["Median baseline", f'{baseline["mae"]:.4f}', f'{baseline["rmse"]:.4f}', f'{baseline["r2"]:.4f}'],
        ], "Evaluation on 70 rows from 20 unseen named models. Lower error and higher R² are better.", [1.8, 1, 1, 1]),
        p(f'Test MAE is {m["baseline_relative_mae_improvement_percent"]:.1f}% lower than the median baseline. '
          "The gap between training CV and test errors is material and should temper expectations "
          "about transfer to new vehicle groups. MAE is average absolute error; RMSE penalizes larger "
          "errors more heavily; R² is a split-specific squared-error comparison with the test mean."),
        figure("charts/heldout_predictions_and_residuals.png", "Figure 1. Predictions and residuals for held-out vehicle names. Individual errors remain substantial despite improvement over the baseline."),
        figure("charts/permutation_importance.png", "Figure 2. Post-selection importance: increase in held-out MAE after input shuffling, with 20-repeat variation. Correlated inputs may share or mask importance."),
        p(f'Present_Price has the largest measured permutation effect: '
          f'{float(importance[0]["mae_increase_mean"]):.3f} dataset price units of added MAE on average. '
          "This is predictive association, not a causal effect. Car_Name importance is zero by "
          "construction because every held-out name is unseen and its one-hot categories are unknown. "
          "Present_Price would be useful operationally only if its definition and timestamp were "
          "verified and the value were available when a prediction is requested."),
        h("5  Limitations and next steps"),
        bullets("The historical convenience sample is small and mixes vehicle types. Location, collection date, currency, condition, service history, and accident history are unverified or missing.",
                "The name-based holdout estimates transfer to unseen names within this file. It does not establish current-market accuracy, transport to a new country, or a production valuation service.",
                "Grouping and exact deduplication reduce direct leakage; hidden repeated listings under different names cannot be ruled out. One seeded holdout is not a population uncertainty interval.",
                "Collect representative, dated and permissioned listings, verify units and predictor availability, and define a deployment-specific validation protocol before using predictions for valuation."),
    ]
    blocks += reproducibility("outputs/metrics.json and data_audit.json record the source SHA-256, duplicate policy, "
                              "split counts, versions, parameters, and errors. split_assignments.csv, cv_results.csv, "
                              "heldout_predictions.csv, and permutation_importance.csv expose the evaluation trail. "
                              "Four chart PNGs are generated. The saved model.joblib is fit on training data only; "
                              "only load serialized models from a trusted source.", repo, tests=4)
    return {"title": "Car Price Prediction with Machine Learning", "repository": repo, "blocks": blocks}


def sales(root):
    repo = "CodeAlpha_SalesPrediction"
    m = load(root, repo)
    a, split = m["data_audit"], m["split"]
    held, baseline = m["heldout"]["selected_model"], m["heldout"]["dummy_mean_baseline"]
    with (root / repo / "outputs" / "tables" / "training_linear_associations.csv").open() as f:
        coefficients = list(csv.DictReader(f))
    with (root / repo / "outputs" / "tables" / "hypothetical_scenarios.csv").open() as f:
        scenarios = list(csv.DictReader(f))
    blocks = [
        h("1  Objective"),
        p("Predict Sales from TV, Radio, and Newspaper advertising measurements, comparing regression "
          "models and exploring how their predictions vary with advertising inputs. The available "
          "cross-sectional data support conditional prediction for new observations. Dated future "
          "forecasting, target segments, and online platforms cannot be evaluated because those fields are absent."),
        h("2  Data and provenance"),
        source("archive (3).zip", "Advertising.csv", "https://www.kaggle.com/datasets/bumba5341/advertisingcsv"),
        table(["Attribute", "Observed data / treatment"], [
            ["Observations", str(a["source_rows"])],
            ["Predictors / target", "TV, Radio, Newspaper / Sales"],
            ["Data quality", "No missing model measurements; no duplicate observations after excluding row index"],
            ["Identifier", "Verified sequential Unnamed: 0 excluded from predictors; retained for row traceability"],
            ["Units", "Observed dataset units; no verified currency or sales-volume scale"],
        ], widths=[1, 2.7]),
        p("No dated campaign, geography, customer segment, platform-detail, price, or macroeconomic "
          "controls are supplied. The analysis preserves observed values and does not assign currency, "
          "create missing variables, or interpret the index as time."),
        h("3  Method and evaluation"),
        p(f'With seed {m["seed"]}, a fixed random 80/20 split creates {split["training_rows"]} training '
          f'and {split["test_rows"]} untouched test rows. A chronological split is unavailable because '
          "there are no dates. All six predeclared candidates use the same five shuffled training-only "
          "cross-validation folds. Median imputation, scaling, and interaction/polynomial transformations "
          "are inside each fold’s pipeline."),
        p("Compare a mean baseline, linear regression, Ridge, a TV × Radio interaction model, quadratic "
          "Ridge, and random forest using fixed hyperparameters documented in make_models(). Lowest "
          "mean training CV RMSE selects the model before the selected estimator and baseline are "
          "evaluated once on the held-out rows. The fitted model remains trained on the 160-row "
          "training partition; it is not refit on the held-out data."),
        h("4  Results and marketing interpretation"),
        table(["Candidate", "CV RMSE ± SD", "CV MAE", "CV R²"], [
            [x["model"], f'{x["cv_rmse_mean"]:.3f} ± {x["cv_rmse_std"]:.3f}', f'{x["cv_mae_mean"]:.3f}', f'{x["cv_r2_mean"]:.3f}']
            for x in m["selection"]["cross_validation"]
        ], "Training-only model comparison. Fold SD is variation across five folds, not a confidence interval.", [2, 1.4, .8, .8]),
        p(f'**Selected model: {m["selection"]["selected_model"]}.** The polynomial feature representation '
          "allows curvature and interactions, with Ridge regularization applied after scaling."),
        table(["Held-out model", "MAE", "RMSE", "R²"], [
            ["Selected quadratic Ridge", f'{held["mae"]:.4f}', f'{held["rmse"]:.4f}', f'{held["r2"]:.4f}'],
            ["Mean baseline", f'{baseline["mae"]:.4f}', f'{baseline["rmse"]:.4f}', f'{baseline["r2"]:.4f}'],
        ], "Untouched 40-row test set. MAE/RMSE use observed Sales units; lower is better. Higher R² is better.", [1.9, 1, 1, 1]),
        figure("charts/03_heldout_predictions_and_residuals.png", "Figure 1. Selected-model held-out predictions and residuals. Strong performance on this split does not establish future-period validity."),
        table(["Training linear reference", "Sales association per 1 SD input increase"], [
            [x["feature"], f'{float(x["coefficient_per_training_standard_deviation"]):.3f}'] for x in coefficients
        ], "Standardized coefficients from the training-only linear reference model, holding the other observed inputs fixed.", [1.2, 2.6]),
        p("TV and Radio show stronger conditional linear associations than Newspaper in this training "
          "sample. The linear reference differs from the selected nonlinear predictor. These coefficients "
          "do not establish an intervention effect, and a small Newspaper coefficient does not establish "
          "a zero causal contribution."),
        figure("charts/04_linear_association_coefficients.png", "Figure 2. Training-only standardized coefficients. Coefficients summarize fitted associations and must not be read as causal return on advertising."),
        table(["Hypothetical input scenario", "Predicted Sales", "Δ from reference"], [
            [x["scenario"], f'{float(x["predicted_sales"]):.3f}', f'{float(x["difference_from_reference_prediction"]):+.3f}']
            for x in scenarios
        ], f'Starting point: actual training source row {m["scenario_reference_source_row_id"]}. All values use observed dataset units.', [2.5, 1.1, 1.1]),
        p("Each sensitivity scenario varies one channel by ±20%, clipped to its observed training "
          "range, while holding the others fixed. Marginal range checks do not guarantee joint "
          "observational support. There is no observed scenario outcome. These are model-based "
          "illustrations rather than causal uplift, guaranteed ROI, or an optimal budget allocation."),
        bullets("Marketing next step: prioritize measured, randomized TV and Radio experiments, including an appropriate Newspaper comparison, to test the observed hypotheses.",
                "Collect dated spend, verified units, channel costs, revenue, segment labels, and outcomes. Predefine evaluation metrics and an adequate validation period.",
                "Use temporal validation once dated records are available. This dataset alone does not justify reallocating a real advertising budget."),
        h("5  Limitations and next steps"),
        p("Only 200 observations and one 40-row holdout are available. Model selection can make the "
          "winning CV score optimistic; the test set provides an independent check within this sample. "
          "Unmeasured confounding, correlated channels, distribution shift, and absent time information "
          "limit marketing interpretation. No forecast for a named future period, causal budget effect, "
          "or assured business return is claimed. Verify dataset provenance, redistribution permission, "
          "and measurement definitions before production use."),
    ]
    blocks += reproducibility("outputs/metrics.json records source SHA-256, model settings, row split IDs, "
                              "CV results, and held-out errors. Tables retain descriptive statistics, correlations, "
                              "fold-level CV scores, training-only linear associations, and hypothetical inputs. "
                              "heldout_predictions.csv records observed and predicted test values. Five PNG charts "
                              "are generated; optional --data and --output-dir arguments support alternate local paths.", repo)
    return {"title": "Sales Prediction using Python", "repository": repo, "blocks": blocks}


def main():
    global NOTEBOOK_VALIDATION
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=here.parent / "codealpha-projects")
    parser.add_argument("--output", type=Path, default=here / "report_content.json")
    args = parser.parse_args()
    validation = json.loads((here / "notebook-validation.json").read_text())
    if not validation["passed"] or any(x["errors"] for x in validation["notebooks"]):
        raise ValueError("Resolve notebook execution errors before composing final reports.")
    NOTEBOOK_VALIDATION = {x["project"]: x for x in validation["notebooks"]}
    projects = [iris(args.project_root), unemployment(args.project_root), car(args.project_root), sales(args.project_root)]
    args.output.write_text(json.dumps({"projects": projects}, indent=2, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
