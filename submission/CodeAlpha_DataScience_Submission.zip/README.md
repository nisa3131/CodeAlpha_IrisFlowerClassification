# CodeAlpha Data Science submission package

Four completed projects for GitHub account **nisa3131**, using the standard design-report layout approved in the conversation. The user requested all four tasks, although the supplied internship document permits a minimum of two or three.

## Projects

| Task | Project | Verified result |
| --- | --- | --- |
| 1 | [Iris Flower Classification](codealpha-projects/CodeAlpha_IrisFlowerClassification/README.md) | Held-out accuracy and macro F1: 1.000 on 30 flowers; grouped evaluation prevents identical measurements crossing splits. |
| 2 | [Unemployment Analysis](codealpha-projects/CodeAlpha_UnemploymentAnalysis/README.md) | Same 25 states: 9.20% Jan–Mar, 23.20% Apr–May, 8.90% Aug–Oct 2020; explicitly unweighted and descriptive. |
| 3 | [Car Price Prediction](codealpha-projects/CodeAlpha_CarPricePrediction/README.md) | Unseen vehicle-name holdout: MAE 2.056, RMSE 3.353, R² 0.584; observed dataset price units. |
| 4 | [Sales Prediction](codealpha-projects/CodeAlpha_SalesPrediction/README.md) | Held-out MAE 0.485, RMSE 0.621, R² 0.988; conditional predictions, without time-series or causal claims. |

Each project includes its uploaded dataset, reproducible Python script, executed notebook, pinned requirements, charts, machine-readable metrics, predictions or cleaned tables, a Markdown report, and PDF/DOCX report exports. GitHub Actions workflows are included; see each repository’s Actions tab for current run status.

## Reports and verification

- [Combined PDF](codealpha-deliverables/CodeAlpha_DataScience_Design_Report.pdf)
- [Editable combined DOCX](codealpha-deliverables/CodeAlpha_DataScience_Design_Report.docx)
- [Combined Markdown](codealpha-deliverables/CodeAlpha_DataScience_Design_Report.md)
- [Validation record](codealpha-deliverables/validation-summary.json)

All four notebooks completed: 17 executed code cells, zero errors. The two Iris and four car validation tests passed. All five raw CSVs match the uploaded ZIP contents byte-for-byte. An independent review checked split isolation, metrics, data comparisons, interpretation, and the publishing helper. Each project README contains the reproduction commands; Python 3.12 was used.

## Re-run all notebooks

From the extracted package root, create and activate a Python 3.12 virtual environment, then run:

```bash
python -m pip install -r codealpha-projects/CodeAlpha_CarPricePrediction/requirements-notebook.txt -r codealpha-projects/CodeAlpha_SalesPrediction/requirements.txt
python -m ipykernel install --sys-prefix --name codealpha --display-name "Python (CodeAlpha)"
python codealpha-deliverables/execute_notebooks.py
```

The helper uses the installed `codealpha` kernel and project-relative working directories. For report regeneration, install `codealpha-deliverables/requirements-report.txt`, then run `author_reports.py` and `build_reports.py` from that directory after the notebooks complete.

## GitHub repositories

All four projects are uploaded. Each remote main branch was independently checked against the local commit, and anonymous GitHub page requests confirmed public access.

- [CodeAlpha_CarPricePrediction](https://github.com/nisa3131/CodeAlpha_CarPricePrediction) — `fbeb21c`
- [CodeAlpha_IrisFlowerClassification](https://github.com/nisa3131/CodeAlpha_IrisFlowerClassification) — `ffbcf8a`
- [CodeAlpha_SalesPrediction](https://github.com/nisa3131/CodeAlpha_SalesPrediction) — `234c0a0`
- [CodeAlpha_UnemploymentAnalysis](https://github.com/nisa3131/CodeAlpha_UnemploymentAnalysis) — `a12d045`

Source, executed notebooks, data, metrics, charts and individual PDF/DOCX reports are committed in each repository. The combined report remains in this package. Live GitHub Actions results were not checked. Portable Git bundles and the publication record are included under codealpha-deliverables.

The user created the empty repositories because this machine blocks GitHub API requests. Upload then succeeded through the existing Git connection. For safe repeat uploads to these existing repositories:

```bash
python codealpha-deliverables/publish_projects.py --projects-root codealpha-projects --visibility public --existing-only
```

The helper allows verified fast-forward updates, uses non-force pushes, and verifies remote commit SHAs. It never replaces divergent remote history. Public visibility was independently checked through anonymous web requests, separately from the API-free helper.

## Submission materials

The `codealpha-deliverables/submission-materials/` folder contains a two-page PDF checklist, an editable checklist, four video-explanation scripts, LinkedIn post drafts and short project descriptions suitable for GitHub's About fields. These are drafts and guidance for your review. No LinkedIn posts or official submission form have been submitted, and no videos have been recorded.

The internship PDF permits any 2 or 3 tasks; all four are available. Follow the official form's task-count limit. Record/post the selected explanation videos with their GitHub links, tag CodeAlpha in your internship-status post, and complete the official form shared in the program's WhatsApp group or email. The supplied materials contain no official form URL or deadline.

Direct shared downloads are hosted at https://github.com/nisa3131/CodeAlpha_IrisFlowerClassification/tree/main/submission . Individual project ZIPs are available from each repository's Code > Download ZIP menu.

This package contains verified project-source snapshots and excludes the shared hosted archive from its own contents. Git bundles refer to the source commits in `repository-manifest.json`; a later Iris commit adds the download folder without changing the analyses.

For a screen-by-screen recording plan in Bengali with exact English speech, open `codealpha-deliverables/submission-materials/CLICK_BY_CLICK_VIDEO_GUIDE_BN.md`. It covers all four projects, with five direct page links per video.

## Other internship instructions

The PDFs also mention LinkedIn internship-status posts, project-explanation videos with repository links, and a submission form shared separately. These are external submission steps, separate from the user's request to complete the technical work on GitHub. No LinkedIn post, message, form submission, or certificate claim has been made. Keep the student ID private and use the official submission form when supplied.

Both uploaded instruction PDFs were identical. Dataset source links are attributed from the PDF; original dataset licensing, collection methodology, and units are documented only to the extent supported by the supplied files. No missing horsepower, marketing segment, dates, or other unavailable fields were fabricated.
